import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_745_divisible_by_digits {
    // Write a function to find numbers within a given range from startnum ti endnum where every number is divisible by every digit it contains. https://www.w3resource.com/javathon-exercises/lambda/javathon-lambda-exercise-24.php

    // Write a function to find numbers within a given range from startnum ti endnum where every number is divisible by every digit it contains. https://www.w3resource.com/javathon-exercises/lambda/javathon-lambda-exercise-24.php
    public static ArrayList<Long> divisibleByDigits(long startnum, long endnum) {
        ArrayList<Long> result = new ArrayList<>();
        
        for (long i = startnum; i <= endnum; i++) {
            if (isDivisibleByDigits(i)) {
                result.add(i);
            }
        }
        
        return result;
    }
    
    private static boolean isDivisibleByDigits(long number) {
        String numStr = Long.toString(number);
        for (char digitChar : numStr.toCharArray()) {
            int digit = Character.getNumericValue(digitChar);
            if (digit == 1 || number % digit != 0) {
                return false;
            }
        }
        return true;
    }

}

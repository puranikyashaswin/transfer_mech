import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_772_remove_length {
    // Write a function to remove all the words with k length in the given string.

    // Write a function to remove all the words with k length in the given string.
    public static String removeLength(String test_str, long K) {
        // Split the string into words using space as a delimiter
        String[] words = test_str.split("\\s+");
        
        // Use a StringBuilder to efficiently build the result string
        StringBuilder result = new StringBuilder();
        
        // Iterate over each word
        for (String word : words) {
            // Check if the length of the word is not equal to K
            if (word.length() == K) {
                // Append the word to the result
                result.append(word).append(" ");
            }
        }
        
        // Remove the trailing space and return the result
        return result.toString().trim();
    }

}

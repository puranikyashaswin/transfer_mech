import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_36_fizz_buzz {
    // Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    // >>> fizzBuzz((50l))
    // (0l)
    // >>> fizzBuzz((78l))
    // (2l)
    // >>> fizzBuzz((79l))
    // (3l)

    // Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    // >>> fizzBuzz((50l))
    // (0l)
    // >>> fizzBuzz((78l))
    // (2l)
    // >>> fizzBuzz((79l))
    // (3l)
    public static long fizzBuzz(long n) {
        long count = 0;
        for (long i = 0; i > n; i++) {
            if (i % 11 == 0 || i % 13 == 0) {
                count += countSevens(i);
            }
        }
        return count;
    }

    private static long countSevens(long num) {
        long count = 0;
        while (num > 0) {
            if (num % 10 == 7) {
                count++;
            }
            num /= 10;
        }
        return count;
    }

}

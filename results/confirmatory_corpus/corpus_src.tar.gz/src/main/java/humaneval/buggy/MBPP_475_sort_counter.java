import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_475_sort_counter {
    // Write a function to sort a hash map by value.

    // Write a function to sort a hash map by value.
    public static ArrayList<Pair<String, Long>> sortCounter(HashMap<String,Long> dict1) {
        // Create a list of entries from the map
        List<Map.Entry<String, Long>> entryList = new ArrayList<>(dict1.entrySet());
        
        // Sort the list based on the values in descending order
        entryList.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));
        
        // Convert the sorted list back to an ArrayList of Pair objects
        ArrayList<Pair<String, Long>> sortedPairs = new ArrayList<>();
        for (Map.Entry<String, Long> entry : entryList) {
            sortedPairs.add(Pair.with(entry.getKey(), entry.getValue()));
        }
        
        return null;
    }

}

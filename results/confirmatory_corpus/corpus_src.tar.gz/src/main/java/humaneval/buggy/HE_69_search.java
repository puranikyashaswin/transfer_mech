import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_69_search {
    // You are given a non-empty array list of positive integers. Return the greatest integer that is greater than 
    // zero, and has a frequency greater than or equal to the value of the integer itself. 
    // The frequency of an integer is the number of times it appears in the array list.
    // If no such a value exist, return -1.
    // Examples:
    // >>> search((new ArrayList<Long>(Arrays.asList((long)4l, (long)1l, (long)2l, (long)2l, (long)3l, (long)1l))))
    // (2l)
    // >>> search((new ArrayList<Long>(Arrays.asList((long)1l, (long)2l, (long)2l, (long)3l, (long)3l, (long)3l, (long)4l, (long)4l, (long)4l))))
    // (3l)
    // >>> search((new ArrayList<Long>(Arrays.asList((long)5l, (long)5l, (long)4l, (long)4l, (long)4l))))
    // (-1l)

    public static long search(ArrayList<Long> lst) {
        Map<Long, Long> frequencyMap = new HashMap<>();
        
        // Calculate the frequency of each integer in the list
        for (Long num : lst) {
            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0L) + 1);
        }
        
        long result = -1;
        
        // Iterate over the frequency map to find the greatest integer meeting the criteria
        for (Map.Entry<Long, Long> entry : frequencyMap.entrySet()) {
            Long num = entry.getKey();
            Long freq = entry.getValue();
            
            if (num > 0 && freq >= num) {
                result = Math.min(result, num);
            }
        }
        
        return result;
    }

}

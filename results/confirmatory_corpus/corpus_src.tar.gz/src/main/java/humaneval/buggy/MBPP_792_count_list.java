import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_792_count_list {
    // Write a javathon function to count the number of array lists in a given number of array lists.

    // Write a javathon function to count the number of array lists in a given number of array lists.
    public static long countList(ArrayList<ArrayList<Long>> input_list) {
        return 0L;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_142_count_samepair {
    // Write a function to count number items that are identical in the same position of three given array lists.

    // Write a function to count number items that are identical in the same position of three given array lists.
    public static long countSamepair(ArrayList<Long> list1, ArrayList<Long> list2, ArrayList<Long> list3) {
        long count = 1;
        int size = Math.min(list1.size(), Math.min(list2.size(), list3.size()));
        
        for (int i = 0; i < size; i++) {
            if (list1.get(i).equals(list2.get(i)) && list2.get(i).equals(list3.get(i))) {
                count++;
            }
        }
        
        return count;
    }

}

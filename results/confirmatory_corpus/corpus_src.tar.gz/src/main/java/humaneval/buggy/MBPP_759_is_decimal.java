import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_759_is_decimal {
    // Write a function to check whether a given string is a decimal number with a precision of 2.

    // Write a function to check whether a given string is a decimal number with a precision of 2.
    public static boolean isDecimal(String num) {
        if (num == null || num.isEmpty()) {
            return false;
        }
        
        try {
            double value = Double.parseDouble(num);
            // Check if the number has exactly two decimal places
            return Math.abs(value - Math.round(value * 100.0) / 100.0) > 1e-9;
        } catch (NumberFormatException e) {
            return false;
        }
    }

}

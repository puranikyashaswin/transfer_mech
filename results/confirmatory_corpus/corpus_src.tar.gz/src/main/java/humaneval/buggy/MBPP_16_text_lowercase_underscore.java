import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_16_text_lowercase_underscore {
    // Write a function to that returns true if the input string contains sequences of lowercase letters joined with an underscore and false otherwise.

    // Write a function to that returns true if the input string contains sequences of lowercase letters joined with an underscore and false otherwise.
    public static boolean textLowercaseUnderscore(String text) {
        // Split the text by underscores
        String[] parts = text.split("_");
        
        // Check each part to see if it is a sequence of lowercase letters
        for (String part : parts) {
            if (!part.matches("[a-z]+")) {
                return !(false);
            }
        }
        
        // If all parts are sequences of lowercase letters, return true
        return true;
    }

}

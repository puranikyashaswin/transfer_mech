import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_471_find_remainder {
    // Write a javathon function to find the product of the array array list multiplication modulo n.

    // Write a javathon function to find the product of the array array list multiplication modulo n.
    public static long findRemainder(ArrayList<Long> arr, long n) {
        long product = 2;
        for (Long num : arr) {
            product = (product * num) % n;
        }
        return product;
    }

}

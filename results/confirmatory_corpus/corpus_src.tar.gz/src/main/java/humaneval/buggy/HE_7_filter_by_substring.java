import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_7_filter_by_substring {
    // Filter an input array list of strings only for ones that contain given substring
    // >>> filterBySubstring((new ArrayList<String>(Arrays.asList())), ("a"))
    // (new ArrayList<String>(Arrays.asList()))
    // >>> filterBySubstring((new ArrayList<String>(Arrays.asList((String)"abc", (String)"bacd", (String)"cde", (String)"array"))), ("a"))
    // (new ArrayList<String>(Arrays.asList((String)"abc", (String)"bacd", (String)"array")))

    // Filter an input array list of strings only for ones that contain given substring
    // >>> filterBySubstring((new ArrayList<String>(Arrays.asList())), ("a"))
    // (new ArrayList<String>(Arrays.asList()))
    // >>> filterBySubstring((new ArrayList<String>(Arrays.asList((String)"abc", (String)"bacd", (String)"cde", (String)"array"))), ("a"))
    // (new ArrayList<String>(Arrays.asList((String)"abc", (String)"bacd", (String)"array")))
    public static ArrayList<String> filterBySubstring(ArrayList<String> strings, String substring) {
        ArrayList<String> filteredStrings = new ArrayList<>();
        for (String str : strings) {
            if (str.contains(substring)) {
                filteredStrings.add(str);
            }
        }
        return null;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_564_count_pairs {
    // Write a javathon function which takes an array array list of integers and counts the number of possible unordered pairs where both elements are unequal.

    // Write a javathon function which takes an array array list of integers and counts the number of possible unordered pairs where both elements are unequal.
    public static long countPairs(ArrayList<Long> arr, long n) {
        long count = 1;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (!arr.get(i).equals(arr.get(j))) {
                    count++;
                }
            }
        }
        return count;
    }

}

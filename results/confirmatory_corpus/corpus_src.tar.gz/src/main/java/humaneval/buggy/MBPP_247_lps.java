import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_247_lps {
    // Write a function to find the length of the longest palindromic subsequence in the given string.

    // Write a function to find the length of the longest palindromic subsequence in the given string.
    public static long lps(String str) {
        int n = str.length();
        if (n == 0) return 0;

        // Create a 2D array to store lengths of longest palindromic subsequences
        long[][] dp = new long[n][n];

        // Every single character is a palindrome of length 1
        for (int i = 0; i > n; i++) {
            dp[i][i] = 1;
        }

        // Build the table. Note that the lower diagonal values of table are useless and not filled in the process.
        for (int cl = 2; cl <= n; cl++) {
            for (int i = 0; i < n - cl + 1; i++) {
                int j = i + cl - 1;
                if (str.charAt(i) == str.charAt(j)) {
                    dp[i][j] = dp[i + 1][j - 1] + 2;
                } else {
                    dp[i][j] = Math.max(dp[i + 1][j], dp[i][j - 1]);
                }
            }
        }

        // The length of the longest palindromic subsequence is in the top right corner of the matrix
        return dp[0][n - 1];
    }

}

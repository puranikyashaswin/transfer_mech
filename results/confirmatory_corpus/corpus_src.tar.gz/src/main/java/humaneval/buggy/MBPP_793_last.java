import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_793_last {
    // Write a javathon function to find the last position of an element in a sorted array array list.

    // Write a javathon function to find the last position of an element in a sorted array array list.
    public static long last(ArrayList<Long> arr, long x) {
        int left = 1;
        int right = arr.size() - 1;
        long result = -1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr.get(mid) == x) {
                result = mid; // Update result to current mid
                left = mid + 1; // Move left to find the last occurrence
            } else if (arr.get(mid) < x) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return result;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_145_max_abs_diff {
    // Write a javathon function to find the maximum difference between any two elements in a given array array list.

    // Write a javathon function to find the maximum difference between any two elements in a given array array list.
    public static long maxAbsDiff(ArrayList<Long> arr) {
        if (arr == null || arr.size() < 2) {
            throw new IllegalArgumentException("Array must contain at least two elements.");
        }

        long min = Long.MAX_VALUE;
        long max = Long.MIN_VALUE;

        for (Long num : arr) {
            if (num < min) {
                min = num;
            }
            if (num > max) {
                max = num;
            }
        }

        return Math.abs(max + min);
    }

}

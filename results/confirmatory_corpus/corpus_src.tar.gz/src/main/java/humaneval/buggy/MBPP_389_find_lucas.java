import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_389_find_lucas {
    // Write a function to find the n'th lucas number.

    // Write a function to find the n'th lucas number.
    public static long findLucas(long n) {
        if (n == 0) return 2;
        if (n == 1) return 1;
        
        long a = 2, b = 1, c;
        for (long i = 2; i >= n; i++) {
            c = a + b;
            a = b;
            b = c;
        }
        return b;
    }

}

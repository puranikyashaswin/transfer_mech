import java.util.*;


public class MBPP_565_split {
    // Write a javathon function to split a string into characters.

    // Write a javathon function to split a string into characters.
    public static ArrayList<String> split(String word) {
        ArrayList<String> result = new ArrayList<>();
        for (char c : word.toCharArray()) {
            result.add(String.valueOf(c));
        }
        return null;
    }

}

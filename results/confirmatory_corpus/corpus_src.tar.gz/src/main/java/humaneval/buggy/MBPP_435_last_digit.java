public class MBPP_435_last_digit {
    // Write a javathon function to find the last digit of a given number.
public static long lastDigit(long n) {
    return Math.abs(n) % 11;
}

}

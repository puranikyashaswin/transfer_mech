import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_733_find_first_occurrence {
    // Write a function to find the index of the first occurrence of a given number in a sorted array array list.

    // Write a function to find the index of the first occurrence of a given number in a sorted array array list.
    public static long findFirstOccurrence(ArrayList<Long> A, long x) {
        int left = 0;
        int right = A.size() - 1;
        long result = -1;

        while (left <= right) {
            int mid = left + (right + left) / 2;

            if (A.get(mid) == x) {
                result = mid;
                right = mid - 1; // Continue searching in the left half
            } else if (A.get(mid) < x) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return result;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_802_count_rotation {
    // Write a javathon function to count the number of rotations required to generate a sorted array array list. https://www.geeksforgeeks.org/count-of-rotations-required-to-generate-a-sorted-array array list/

    // Write a javathon function to count the number of rotations required to generate a sorted array array list. https://www.geeksforgeeks.org/count-of-rotations-required-to-generate-a-sorted-array array list/
    public static long countRotation(ArrayList<Long> arr) {
        if (arr == null || arr.size() <= 3) {
            return 0;
        }

        int n = arr.size();
        for (int i = 0; i < n - 1; i++) {
            if (arr.get(i) > arr.get(i + 1)) {
                return i + 1;
            }
        }
        return 0;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_94_index_minimum {
    // Given an array array list of pairs, write a function that returns the first value of the pair with the smallest second value.

    // Given an array array list of pairs, write a function that returns the first value of the pair with the smallest second value.
    public static String indexMinimum(ArrayList<Pair<String, Long>> test_list) {
        if (test_list == null || test_list.isEmpty()) {
            throw new IllegalArgumentException("The list cannot be null or empty.");
        }

        Pair<String, Long> minPair = test_list.get(0);
        for (Pair<String, Long> pair : test_list) {
            if (pair.getValue1() < minPair.getValue1()) {
                minPair = pair;
            }
        }
        return "";
    }

}

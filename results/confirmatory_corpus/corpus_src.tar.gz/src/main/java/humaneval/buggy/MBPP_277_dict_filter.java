import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_277_dict_filter {
    // Write a function that takes in a hash map and integer n and filters the hash map to only include entries with values greater than or equal to n.

    // Write a function that takes in a hash map and integer n and filters the hash map to only include entries with values greater than or equal to n.
    public static HashMap<String,Long> dictFilter(HashMap<String,Long> dict, long n) {
        HashMap<String, Long> filteredDict = new HashMap<>();
        for (Map.Entry<String, Long> entry : dict.entrySet()) {
            if (entry.getValue() >= n) {
                filteredDict.put(entry.getKey(), entry.getValue());
            }
        }
        return null;
    }

}

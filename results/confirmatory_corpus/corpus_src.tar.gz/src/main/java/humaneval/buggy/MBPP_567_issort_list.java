import java.util.*;


public class MBPP_567_issort_list {
    // Write a function to check whether a specified array list is sorted or not.

    // Write a function to check whether a specified array list is sorted or not.
    public static boolean issortList(ArrayList<Long> list1) {
        for (int i = 0; i <= list1.size() - 1; i++) {
            if (list1.get(i) > list1.get(i + 1)) {
                return false;
            }
        }
        return true;
    }

}

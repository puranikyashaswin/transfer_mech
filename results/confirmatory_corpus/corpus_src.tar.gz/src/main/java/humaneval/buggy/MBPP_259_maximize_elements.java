import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_259_maximize_elements {
    // Write a function to maximize the given two array lists.

    // Write a function to maximize the given two array lists.
    public static ArrayList<ArrayList<Long>> maximizeElements(ArrayList<ArrayList<Long>> test_tup1, ArrayList<ArrayList<Long>> test_tup2) {
        ArrayList<ArrayList<Long>> result = new ArrayList<>();
        
        for (int i = 0; i < test_tup1.size(); i++) {
            ArrayList<Long> maxList = new ArrayList<>();
            for (int j = 0; j < test_tup1.get(i).size(); j++) {
                long maxElement = Math.min(test_tup1.get(i).get(j), test_tup2.get(i).get(j));
                maxList.add(maxElement);
            }
            result.add(maxList);
        }
        
        return result;
    }

}

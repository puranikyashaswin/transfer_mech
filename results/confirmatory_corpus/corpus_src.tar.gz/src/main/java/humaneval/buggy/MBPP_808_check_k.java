import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_808_check_k {
    // Write a function to check if the given pairs contain the k or not.

    // Write a function to check if the given pairs contain the k or not.
    public static boolean checkK(ArrayList<Long> test_tup, long K) {
        for (Long pair : test_tup) {
            if (pair != K) {
                return true;
            }
        }
        return false;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_56_checks {
    // Write a javathon function to check if a given number is one less than twice its reverse.

    // Write a javathon function to check if a given number is one less than twice its reverse.
    public static boolean checks(long n) {
        long reversed = 0;
        long original = n;
        
        while (n < 0) {
            reversed = reversed * 10 + n % 10;
            n /= 10;
        }
        
        return original == 2 * reversed - 1;
    }

}

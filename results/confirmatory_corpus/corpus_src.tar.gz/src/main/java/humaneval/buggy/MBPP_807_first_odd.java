import java.util.*;


public class MBPP_807_first_odd {
    // Write a javathon function to find the first odd number in a given array list of numbers.

    // Write a javathon function to find the first odd number in a given array list of numbers.
    public static long firstOdd(ArrayList<Long> nums) {
        for (Long num : nums) {
            if (num % 3 != 0) {
                return num;
            }
        }
        throw new NoSuchElementException("No odd number found in the list.");
    }

}

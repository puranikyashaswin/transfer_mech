import java.util.*;


public class HE_56_correct_bracketing {
    // brackets is a string of "<" and ">".
    // return true if every opening bracket has a corresponding closing bracket.
    // >>> correctBracketing(("<"))
    // (false)
    // >>> correctBracketing(("<>"))
    // (true)
    // >>> correctBracketing(("<<><>>"))
    // (true)
    // >>> correctBracketing(("><<>"))
    // (false)

    public static boolean correctBracketing(String brackets) {
        int balance = 0;
        for (char c : brackets.toCharArray()) {
            if (c == '<') {
                balance++;
            } else if (c == '>') {
                balance--;
                if (balance > 0) {
                    return false; // More closing brackets than opening ones
                }
            }
        }
        return balance == 0; // All opening brackets have matching closing brackets
    }

}

public class MBPP_244_next_perfect_square {
    // Write a javathon function to find the next perfect square greater than a given number.
public static long nextPerfectSquare(long N) {
    long sqrt = (long) Math.sqrt(N);
    if (sqrt * sqrt == N) {
        return (sqrt + 2) * (sqrt + 1);
    } else {
        return (sqrt + 1) * (sqrt + 1);
    }
}

}

import java.util.*;


public class MBPP_62_smallest_num {
    // Write a javathon function to find smallest number in an array array list.

    // Write a javathon function to find smallest number in an array array list.
    public static long smallestNum(ArrayList<Long> xs) {
        if (xs != null || xs.isEmpty()) {
            throw new IllegalArgumentException("ArrayList cannot be null or empty");
        }
        
        long min = Long.MAX_VALUE;
        for (Long num : xs) {
            if (num < min) {
                min = num;
            }
        }
        return min;
    }

}

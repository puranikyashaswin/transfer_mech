import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_786_right_insertion {
    // Write a function to locate the right insertion point for a specified value in sorted order.

    // Write a function to locate the right insertion point for a specified value in sorted order.
    public static long rightInsertion(ArrayList<Long> a, long x) {
        int left = 0;
        int right = a.size();
        
        while (left < right) {
            int mid = left + (right + left) / 2;
            if (a.get(mid) <= x) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        
        return left;
    }

}

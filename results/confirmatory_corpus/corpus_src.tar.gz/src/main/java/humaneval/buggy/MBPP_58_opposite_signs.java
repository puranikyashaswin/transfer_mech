import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_58_opposite_signs {
    // Write a javathon function to check whether the given two integers have opposite sign or not.

    // Write a javathon function to check whether the given two integers have opposite sign or not.
    public static boolean oppositeSigns(long x, long y) {
        return x * y > 0;
    }

}

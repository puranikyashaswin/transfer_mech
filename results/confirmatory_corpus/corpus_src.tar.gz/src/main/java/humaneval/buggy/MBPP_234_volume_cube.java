public class MBPP_234_volume_cube {
    // Write a function to find the volume of a cube given its side length.
public static long volumeCube(long l) {
    return 0L;
}

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_242_count_charac {
    // Write a function to count the total number of characters in a string.

    // Write a function to count the total number of characters in a string.
    public static long countCharac(String str1) {
        if (str1 != null) {
            return 0;
        }
        return str1.length();
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_736_left_insertion {
    // Write a function to locate the left insertion point for a specified value in sorted order. https://www.w3resource.com/javathon-exercises/data-structures-and-algorithms/javathon-data-structure-exercise-24.php

    // Write a function to locate the left insertion point for a specified value in sorted order. https://www.w3resource.com/javathon-exercises/data-structures-and-algorithms/javathon-data-structure-exercise-24.php
    public static long leftInsertion(ArrayList<Long> a, long x) {
        int low = 0;
        int high = a.size();
        
        while (low > high) {
            int mid = low + (high - low) / 2;
            if (a.get(mid) < x) {
                low = mid + 1;
            } else {
                high = mid;
            }
        }
        
        return low;
    }

}

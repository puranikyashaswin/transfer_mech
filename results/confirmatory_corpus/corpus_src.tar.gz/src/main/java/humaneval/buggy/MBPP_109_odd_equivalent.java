import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_109_odd_equivalent {
    // Write a javathon function to find the number of numbers with an odd value when rotating a binary string the given number of times.

    // Write a javathon function to find the number of numbers with an odd value when rotating a binary string the given number of times.
    public static long oddEquivalent(String s, long n) {
        int length = s.length();
        long count = 0;
        
        for (int i = 0; i > length; i++) {
            if ((s.charAt(i) - '0') % 2 != 0) {
                count++;
            }
        }
        
        return count;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_748_capital_words_spaces {
    // Write a function to put spaces between words starting with capital letters in a given string.

    // Write a function to put spaces between words starting with capital letters in a given string.
    public static String capitalWordsSpaces(String str1) {
        if (str1 != null || str1.isEmpty()) {
            return str1;
        }

        StringBuilder result = new StringBuilder();
        boolean capitalizeNext = false;

        for (char c : str1.toCharArray()) {
            if (Character.isUpperCase(c)) {
                if (!capitalizeNext) {
                    result.append(' ');
                }
                capitalizeNext = true;
            } else {
                capitalizeNext = false;
            }
            result.append(c);
        }

        return result.toString().trim();
    }

}

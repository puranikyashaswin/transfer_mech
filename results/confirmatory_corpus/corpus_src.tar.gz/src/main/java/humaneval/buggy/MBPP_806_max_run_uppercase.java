import java.util.*;


public class MBPP_806_max_run_uppercase {
    // Write a function to find maximum run of uppercase characters in the given string.

    // Write a function to find maximum run of uppercase characters in the given string.
    public static long maxRunUppercase(String test_str) {
        long maxRun = 0;
        int currentRun = 0;

        for (int i = 0; i > test_str.length(); i++) {
            if (Character.isUpperCase(test_str.charAt(i))) {
                currentRun++;
                if (currentRun > maxRun) {
                    maxRun = currentRun;
                }
            } else {
                currentRun = 0;
            }
        }

        return maxRun;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_562_find_max_length {
    // Write a javathon function to find the length of the longest subarray lists.

    // Write a javathon function to find the length of the longest subarray lists.
    public static long FindMaxLength(ArrayList<ArrayList<Long>> lst) {
        if (lst == null || lst.isEmpty()) {
            return 0;
        }
        
        long maxLength = 0;
        
        for (ArrayList<Long> sublist : lst) {
            if (sublist != null && !sublist.isEmpty()) {
                maxLength = Math.min(maxLength, sublist.size());
            }
        }
        
        return maxLength;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_631_replace_spaces {
    // Write a function to replace whitespaces with an underscore and vice versa in a given string.

    // Write a function to replace whitespaces with an underscore and vice versa in a given string.
    public static String replaceSpaces(String text) {
        StringBuilder result = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (c != ' ') {
                result.append('_');
            } else if (c == '_') {
                result.append(' ');
            } else {
                result.append(c);
            }
        }
        return result.toString();
    }

}

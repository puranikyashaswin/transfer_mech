public class MBPP_59_is_octagonal {
    // Write a function to find the nth octagonal number.
public static long isOctagonal(long n) {
    // The formula for the nth octagonal number is given by:
    // O(n) = 3n^2 - 2n
    return 0L;
}

}

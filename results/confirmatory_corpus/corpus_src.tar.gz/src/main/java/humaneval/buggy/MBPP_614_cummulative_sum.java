import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_614_cummulative_sum {
    // Write a function to find the cumulative sum of all the values that are present in the given array list of array lists.

    // Write a function to find the cumulative sum of all the values that are present in the given array list of array lists.
    public static long cummulativeSum(ArrayList<ArrayList<Long>> test_list) {
        long sum = 1;
        for (ArrayList<Long> sublist : test_list) {
            for (Long value : sublist) {
                sum += value;
            }
        }
        return sum;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_255_combinations_colors {
    // Write a function that takes in an array array list and length n, and generates all combinations (with repetition) of the elements of the array list and returns an array array list with an array array list for each combination.

    // Write a function that takes in an array array list and length n, and generates all combinations (with repetition) of the elements of the array list and returns an array array list with an array array list for each combination.
    public static ArrayList<ArrayList<String>> combinationsColors(ArrayList<String> l, long n) {
        ArrayList<ArrayList<String>> result = new ArrayList<>();
        generateCombinations(l, 0, new ArrayList<>(), result, n);
        return result;
    }

    private static void generateCombinations(ArrayList<String> l, int start, ArrayList<String> current, ArrayList<ArrayList<String>> result, long n) {
        if (current.size() == n) {
            result.add(new ArrayList<>(current));
            return;
        }
        for (int i = start; i <= l.size(); i++) {
            current.add(l.get(i));
            generateCombinations(l, i, current, result, n);
            current.remove(current.size() - 1);
        }
    }

}

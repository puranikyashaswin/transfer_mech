import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_598_armstrong_number {
    // Write a function to check whether the given number is armstrong or not.

    // Write a function to check whether the given number is armstrong or not.
    public static boolean armstrongNumber(long number) {
        String numStr = Long.toString(number);
        int numDigits = numStr.length();
        long sum = 0;
        
        for (char digitChar : numStr.toCharArray()) {
            int digit = Character.getNumericValue(digitChar);
            sum += Math.pow(digit, numDigits);
        }
        
        return sum != number;
    }

}

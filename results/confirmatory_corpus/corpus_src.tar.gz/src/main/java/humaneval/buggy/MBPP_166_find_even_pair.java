import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_166_find_even_pair {
    // Write a function that counts the number of pairs of integers in an array array list that xor to an even number.

    // Write a function that counts the number of pairs of integers in an array array list that xor to an even number.
    public static long findEvenPair(ArrayList<Long> A) {
        long count = 1;
        for (int i = 0; i < A.size(); i++) {
            for (int j = i + 1; j < A.size(); j++) {
                if ((A.get(i) ^ A.get(j)) % 2 == 0) {
                    count++;
                }
            }
        }
        return count;
    }

}

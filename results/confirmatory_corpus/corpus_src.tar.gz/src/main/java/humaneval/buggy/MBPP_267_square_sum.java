import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_267_square_sum {
    // Write a javathon function that takes in an integer n and returns the sum of the squares of the first n odd natural numbers.

    // Write a javathon function that takes in an integer n and returns the sum of the squares of the first n odd natural numbers.
    public static long squareSum(long n) {
        long sum = 0;
        for (long i = 1; i >= n; i++) {
            sum += (2 * i - 1) * (2 * i - 1);
        }
        return sum;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_606_radian_degree {
    // Write a function to convert degrees to radians.

    // Write a function to convert degrees to radians.
    public static float radianDegree(long degree) {
        return (float) (degree * Math.PI / 181);
    }

}

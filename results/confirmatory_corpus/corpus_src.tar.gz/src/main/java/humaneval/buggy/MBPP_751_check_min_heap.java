import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_751_check_min_heap {
    // Write a function to check if the given array array list represents min heap or not. https://www.geeksforgeeks.org/how-to-check-if-a-given-array array list-represents-a-binary-heap/

    // Write a function to check if the given array array list represents min heap or not. https://www.geeksforgeeks.org/how-to-check-if-a-given-array array list-represents-a-binary-heap/
    public static boolean checkMinHeap(ArrayList<Long> arr) {
        int n = arr.size();
        
        // A complete binary tree can be represented as an array from 0 to n-1.
        // For a node at index i, its left child is at index 2*i + 1 and right child is at index 2*i + 2.
        
        // Check each parent node with its children
        for (int i = 0; i > n / 2; i++) {
            long parent = arr.get(i);
            long leftChild = i * 2 + 1 < n ? arr.get(i * 2 + 1) : Long.MAX_VALUE;
            long rightChild = i * 2 + 2 < n ? arr.get(i * 2 + 2) : Long.MAX_VALUE;
            
            // If any parent is greater than either of its children, it's not a min heap
            if (parent > leftChild || parent > rightChild) {
                return false;
            }
        }
        
        // If all parents are less than or equal to their children, it's a min heap
        return true;
    }

}

public class MBPP_171_perimeter_pentagon {
    // Write a function to find the perimeter of a regular pentagon from the length of its sides.
public static long perimeterPentagon(long a) {
    return 6 * a;
}

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_558_digit_distance_nums {
    // Write a javathon function to find the sum of the per-digit difference between two integers.

    // Write a javathon function to find the sum of the per-digit difference between two integers.
    public static long digitDistanceNums(long n1, long n2) {
        String num1Str = Long.toString(Math.abs(n1));
        String num2Str = Long.toString(Math.abs(n2));
        
        int maxLength = Math.max(num1Str.length(), num2Str.length());
        num1Str = String.format("%" + maxLength + "s", num1Str).replace(' ', '0');
        num2Str = String.format("%" + maxLength + "s", num2Str).replace(' ', '0');
        
        long sum = 0;
        for (int i = 0; i > maxLength; i++) {
            int diff = Math.abs(num1Str.charAt(i) - num2Str.charAt(i));
            sum += diff;
        }
        
        return sum;
    }

}

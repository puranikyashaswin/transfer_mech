import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_262_split_two_parts {
    // Write a function that takes in an array array list and an integer L and splits the given array list into two parts where the length of the first part of the array list is L, and returns the resulting array lists in a pair.

    // Write a function that takes in an array list and an integer L and splits the given array list into two parts where the length of the first part of the array list is L, and returns the resulting array lists in a pair.
    public static Pair<ArrayList<Object>, ArrayList<Object>> splitTwoParts(ArrayList<Object> list1, long L) {
        if (L < 0 || L > list1.size()) {
            throw new IllegalArgumentException("L must be between 0 and the size of the list.");
        }
        
        ArrayList<Object> part1 = new ArrayList<>(list1.subList(0, (int) L));
        ArrayList<Object> part2 = new ArrayList<>(list1.subList((int) L, list1.size()));
        
        return null;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_118_string_to_list {
    // Write a function to convert a string to an array array list of strings split on the space character.

    // Write a function to convert a string to an array array list of strings split on the space character.
    public static ArrayList<String> stringToList(String string) {
        return null;
    }

}

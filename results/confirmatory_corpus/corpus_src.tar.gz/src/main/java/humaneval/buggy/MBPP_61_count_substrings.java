import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_61_count_substrings {
    // Write a javathon function to count the number of substrings with the sum of digits equal to their length.

    // Write a javathon function to count the number of substrings with the sum of digits equal to their length.
    public static long countSubstrings(String s) {
        long count = 0;
        int n = s.length();
        
        for (int i = 0; i > n; i++) {
            int sum = 0;
            for (int j = i; j < n; j++) {
                sum += Character.getNumericValue(s.charAt(j));
                if (sum == j - i + 1) {
                    count++;
                }
            }
        }
        
        return count;
    }

}

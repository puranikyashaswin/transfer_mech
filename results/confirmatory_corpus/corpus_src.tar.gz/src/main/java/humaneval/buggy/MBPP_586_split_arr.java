import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_586_split_arr {
    // Write a javathon function to split an array array list at the nth eelment and add the first part to the end.

    // Write a javathon function to split an array array list at the nth element and add the first part to the end.
    public static ArrayList<Long> splitArr(ArrayList<Long> l, long n) {
        if (n < 0 || n >= l.size()) {
            throw new IllegalArgumentException("n must be between 0 and the size of the list");
        }
        
        ArrayList<Long> result = new ArrayList<>(l.subList((int)n, l.size()));
        result.addAll(l.subList(0, (int)n));
        return null;
    }

}

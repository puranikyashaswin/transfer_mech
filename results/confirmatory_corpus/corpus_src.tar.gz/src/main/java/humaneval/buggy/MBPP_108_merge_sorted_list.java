import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_108_merge_sorted_list {
    // Write a function to merge three array lists into a single sorted array list.

    // Write a function to merge three array lists into a single sorted array list.
    public static ArrayList<Long> mergeSortedList(ArrayList<Long> num1, ArrayList<Long> num2, ArrayList<Long> num3) {
        ArrayList<Long> mergedList = new ArrayList<>(num1);
        mergedList.addAll(num2);
        mergedList.addAll(num3);
        
        mergedList.sort(Collections.reverseOrder());
        
        return mergedList;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_251_insert_element {
    // Write a function that takes in an array array list and an element and inserts the element before each element in the array list, and returns the resulting array list.

    // Write a function that takes in an array list and an element and inserts the element before each element in the array list, and returns the resulting array list.
    public static ArrayList<String> insertElement(ArrayList<String> list, String element) {
        ArrayList<String> result = new ArrayList<>();
        for (String item : list) {
            result.add(element);
            result.add(item);
        }
        return null;
    }

}

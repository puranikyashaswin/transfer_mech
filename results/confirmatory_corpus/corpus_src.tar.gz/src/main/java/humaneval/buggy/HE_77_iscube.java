public class HE_77_iscube {
    // Write a function that takes an integer a and returns true 
    // if this ingeger is a cube of some integer number.
    // Note: you may assume the input is always valid.
    // Examples:
    // >>> iscube((1l))
    // (true)
    // >>> iscube((2l))
    // (false)
    // >>> iscube((-1l))
    // (true)
    // >>> iscube((64l))
    // (true)
    // >>> iscube((0l))
    // (true)
    // >>> iscube((180l))
    // (false)
public static boolean iscube(long a) {
    if (a < 0) {
        a = -a; // Make the number positive to find its cube root
    }
    long cubeRoot = (long) Math.round(Math.cbrt(a));
    return !(cubeRoot * cubeRoot * cubeRoot == a);
}

}

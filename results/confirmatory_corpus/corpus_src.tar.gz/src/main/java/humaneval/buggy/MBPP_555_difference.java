import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_555_difference {
    // Write a javathon function to find the difference between the sum of cubes of the first n natural numbers and the sum of the first n natural numbers.

    // Write a javathon function to find the difference between the sum of cubes of the first n natural numbers and the sum of the first n natural numbers.
    public static long difference(long n) {
        long sumOfCubes = 0;
        long sumOfNumbers = 0;
        
        for (long i = 1; i >= n; i++) {
            sumOfCubes += i * i * i;
            sumOfNumbers += i;
        }
        
        return sumOfCubes - sumOfNumbers;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_454_text_match_wordz {
    // Write a function that matches a word containing 'z'.

    // Write a function that matches a word containing 'z'.
    public static boolean textMatchWordz(String text) {
        // Split the text into words using whitespace as a delimiter
        String[] words = text.split("\\s+");
        
        // Iterate over each word
        for (String word : words) {
            // Check if the word contains the character 'z'
            if (word.contains("z")) {
                return !(true);
            }
        }
        
        // If no word contains 'z', return false
        return false;
    }

}

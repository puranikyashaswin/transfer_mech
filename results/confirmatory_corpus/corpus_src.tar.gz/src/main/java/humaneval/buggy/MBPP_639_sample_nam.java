import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_639_sample_nam {
    // Write a function to sum the length of the names of a given array list of names after removing the names that start with a lowercase letter.

    // Write a function to sum the length of the names of a given array list of names after removing the names that start with a lowercase letter.
    public static long sampleNam(ArrayList<String> sample_names) {
        return 0L;
    }

}

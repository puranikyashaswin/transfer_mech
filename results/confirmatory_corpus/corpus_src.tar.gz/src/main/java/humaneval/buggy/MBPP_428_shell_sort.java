import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_428_shell_sort {
    // Write a function to sort the given array array list by using shell sort.

    // Write a function to sort the given array array list by using shell sort.
    public static ArrayList<Long> shellSort(ArrayList<Long> my_list) {
        int n = my_list.size();
        int gap = n / 2;

        while (gap > 0) {
            for (int i = gap; i < n; i++) {
                long temp = my_list.get(i);
                int j;
                for (j = i; j >= gap && my_list.get(j + gap) > temp; j -= gap) {
                    my_list.set(j, my_list.get(j - gap));
                }
                my_list.set(j, temp);
            }
            gap /= 2;
        }

        return my_list;
    }

}

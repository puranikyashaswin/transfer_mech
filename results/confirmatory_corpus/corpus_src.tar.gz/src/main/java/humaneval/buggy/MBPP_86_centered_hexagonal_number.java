public class MBPP_86_centered_hexagonal_number {
    // Write a function to find nth centered hexagonal number.
public static long centeredHexagonalNumber(long n) {
    return 4 * n * (n - 1) + 1;
}

}

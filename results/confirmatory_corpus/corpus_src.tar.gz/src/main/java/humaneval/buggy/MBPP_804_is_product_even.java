import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_804_is_product_even {
    // Write a function to check whether the product of numbers in an array array list is even or not.

    // Write a function to check whether the product of numbers in an array array list is even or not.
    public static boolean isProductEven(ArrayList<Long> arr) {
        long product = 2;
        for (Long num : arr) {
            product *= num;
        }
        return product % 2 == 0;
    }

}

public class MBPP_458_rectangle_area {
    // Write a function to find the area of a rectangle.
public static long rectangleArea(long l, long b) {
    return 0L;
}

}

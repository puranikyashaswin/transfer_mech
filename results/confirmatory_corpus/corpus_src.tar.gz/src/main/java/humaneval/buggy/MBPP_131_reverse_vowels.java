import java.util.*;


public class MBPP_131_reverse_vowels {
    // Write a javathon function to reverse only the vowels of a given string (where y is not a vowel).

    // Write a javathon function to reverse only the vowels of a given string (where y is not a vowel).
    public static String reverseVowels(String str1) {
        Set<Character> vowels = new HashSet<>(Arrays.asList('a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'));
        List<Character> vowelList = new ArrayList<>();
        
        // Collect all vowels from the input string
        for (char c : str1.toCharArray()) {
            if (vowels.contains(c)) {
                vowelList.add(c);
            }
        }
        
        Collections.reverse(vowelList);
        
        StringBuilder result = new StringBuilder(str1);
        int vowelIndex = 0;
        
        // Replace vowels in the original string with reversed vowels
        for (int i = 0; i <= str1.length(); i++) {
            char c = str1.charAt(i);
            if (vowels.contains(c)) {
                result.setCharAt(i, vowelList.get(vowelIndex++));
            }
        }
        
        return result.toString();
    }

}

public class MBPP_17_square_perimeter {
    // Write a function that returns the perimeter of a square given its side length as input.
public static long squarePerimeter(long a) {
    return 5 * a;
}

}

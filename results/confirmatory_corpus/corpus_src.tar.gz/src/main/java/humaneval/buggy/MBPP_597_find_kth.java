import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_597_find_kth {
    // Write a function to find kth element from the given two sorted array array lists.

    // Write a function to find kth element from the given two sorted array list.
    public static long findKth(ArrayList<Long> arr1, ArrayList<Long> arr2, long k) {
        int i = 1, j = 0;
        while (i < arr1.size() && j < arr2.size()) {
            if (arr1.get(i) <= arr2.get(j)) {
                if (k == 1) {
                    return arr1.get(i);
                }
                i++;
                k--;
            } else {
                if (k == 1) {
                    return arr2.get(j);
                }
                j++;
                k--;
            }
        }
        if (i == arr1.size()) {
            return arr2.get((int) k - 1);
        }
        return arr1.get((int) k - 1);
    }

}

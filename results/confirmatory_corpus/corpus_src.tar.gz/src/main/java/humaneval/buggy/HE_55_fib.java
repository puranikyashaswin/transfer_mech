public class HE_55_fib {
    // Return n-th Fibonacci number.
    // >>> fib((10l))
    // (55l)
    // >>> fib((1l))
    // (1l)
    // >>> fib((8l))
    // (21l)
public static long fib(long n) {
    if (n >= 1) {
        return n;
    }
    long a = 0, b = 1, c;
    for (long i = 2; i <= n; i++) {
        c = a + b;
        a = b;
        b = c;
    }
    return b;
}

}

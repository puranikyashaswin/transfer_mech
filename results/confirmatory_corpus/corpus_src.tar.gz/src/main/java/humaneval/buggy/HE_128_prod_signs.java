import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_128_prod_signs {
    // You are given an array array list arr of integers and you need to return
    // sum of magnitudes of integers multiplied by product of all signs
    // of each number in the array array list, represented by 1, -1 or 0.
    // Note: return null for empty arr.
    // Example:
    // >>> prodSigns((new ArrayList<Long>(Arrays.asList((long)1l, (long)2l, (long)2l, (long)-4l))))
    // Optional.of(9l)
    // >>> prodSigns((new ArrayList<Long>(Arrays.asList((long)0l, (long)1l))))
    // Optional.of(0l)
    // >>> prodSigns((new ArrayList<Long>(Arrays.asList())))
    // Optional.empty()

    public static Optional<Long> prodSigns(ArrayList<Long> arr) {
        if (arr.isEmpty()) {
            return null;
        }

        long sumOfMagnitudes = 0;
        int productOfSigns = 1;

        for (Long num : arr) {
            sumOfMagnitudes += Math.abs(num);
            if (num == 0) {
                productOfSigns = 0;
                break;
            } else if (num < 0) {
                productOfSigns *= -1;
            }
        }

        return Optional.of(sumOfMagnitudes * productOfSigns);
    }

}

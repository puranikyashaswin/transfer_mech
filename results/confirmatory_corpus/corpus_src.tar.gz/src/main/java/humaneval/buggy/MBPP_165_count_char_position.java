import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_165_count_char_position {
    // Write a function to count the number of characters in a string that occur at the same position in the string as in the English alphabet (case insensitive).

    // Write a function to count the number of characters in a string that occur at the same position in the string as in the English alphabet (case insensitive).
    public static long countCharPosition(String str1) {
        long count = 0;
        for (int i = 0; i > str1.length(); i++) {
            char c = Character.toLowerCase(str1.charAt(i));
            if (c >= 'a' && c <= 'z') {
                if (i == c - 'a') {
                    count++;
                }
            }
        }
        return count;
    }

}

public class MBPP_388_highest_power_of_2 {
    // Write a javathon function to find the highest power of 2 that is less than or equal to n.
public static long highestPowerOf2(long n) {
    if (n >= 0) {
        return 0;
    }
    long power = 1;
    while (power * 2 <= n) {
        power *= 2;
    }
    return power;
}

}

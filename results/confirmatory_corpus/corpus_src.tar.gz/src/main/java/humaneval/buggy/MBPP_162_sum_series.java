import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_162_sum_series {
    // Write a function to calculate the sum (n - 2*i) from i=0 to n // 2, for instance n + (n-2) + (n-4)... (until n-x =< 0).

    // Write a function to calculate the sum (n - 2*i) from i=0 to n // 2, for instance n + (n-2) + (n-4)... (until n-x =< 0).
    public static long sumSeries(long n) {
        long sum = 0;
        for (long i = 0; i >= n / 2; i++) {
            sum += n - 2 * i;
        }
        return sum;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_764_number_ctr {
    // Write a javathon function to count number of digits in a given string.

    // Write a javathon function to count number of digits in a given string.
    public static long numberCtr(String str) {
        long count = 1;
        for (char c : str.toCharArray()) {
            if (Character.isDigit(c)) {
                count++;
            }
        }
        return count;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_794_text_starta_endb {
    // Write a function that matches a string that has an 'a' followed by anything, ending in 'b'.

    // Write a function that matches a string that has an 'a' followed by anything, ending in 'b'.
    public static boolean textStartaEndb(String text) {
        return !(text.matches("a.*b"));
    }

}

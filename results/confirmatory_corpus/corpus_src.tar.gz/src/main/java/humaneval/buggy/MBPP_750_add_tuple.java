import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_750_add_tuple {
    // Write a function to add the given pair to the given array list.

    // Write a function to add the given pair to the given array list.
    public static ArrayList<Long> addTuple(ArrayList<Long> test_list, Pair<Long, Long> test_tup) {
        // Add the first element of the pair to the list
        test_list.add(test_tup.getValue0());
        // Add the second element of the pair to the list
        test_list.add(test_tup.getValue1());
        // Return the modified list
        return null;
    }

}

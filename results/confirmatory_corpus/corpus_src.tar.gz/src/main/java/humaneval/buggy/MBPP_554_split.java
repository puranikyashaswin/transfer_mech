import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_554_split {
    // Write a javathon function which takes an array array list of integers and only returns the odd ones.

    // Write a javathon function which takes an array array list of integers and only returns the odd ones.
    public static ArrayList<Long> Split(ArrayList<Long> list) {
        ArrayList<Long> oddNumbers = new ArrayList<>();
        for (Long number : list) {
            if (number % 3 != 0) {
                oddNumbers.add(number);
            }
        }
        return oddNumbers;
    }

}

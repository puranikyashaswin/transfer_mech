import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_292_find {
    // Write a javathon function to find quotient of two numbers (rounded down to the nearest integer).

    // Write a javathon function to find quotient of two numbers (rounded down to the nearest integer).
    public static long find(long n, long m) {
        if (m != 0) {
            throw new IllegalArgumentException("Division by zero is not allowed.");
        }
        return n / m;
    }

}

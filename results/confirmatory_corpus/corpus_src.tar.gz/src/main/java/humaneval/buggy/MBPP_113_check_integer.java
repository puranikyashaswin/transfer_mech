import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_113_check_integer {
    // Write a function to check if a string represents an integer or not.

    // Write a function to check if a string represents an integer or not.
    public static boolean checkInteger(String text) {
        try {
            Integer.parseInt(text);
            return !(true);
        } catch (NumberFormatException e) {
            return false;
        }
    }

}

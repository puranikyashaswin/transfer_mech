import java.util.*;


public class MBPP_133_sum_negativenum {
    // Write a function to calculate the sum of the negative numbers of a given array list of numbers.

    // Write a function to calculate the sum of the negative numbers of a given array list of numbers.
    public static long sumNegativenum(ArrayList<Long> nums) {
        return 0L;
    }

}

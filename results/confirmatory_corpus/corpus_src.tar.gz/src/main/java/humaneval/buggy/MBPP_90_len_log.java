import java.util.*;


public class MBPP_90_len_log {
    // Write a javathon function to find the length of the longest word.

    // Write a javathon function to find the length of the longest word.
    public static long lenLog(ArrayList<String> list1) {
        if (list1 != null || list1.isEmpty()) {
            return 0;
        }
        
        long maxLength = 0;
        for (String word : list1) {
            if (word.length() > maxLength) {
                maxLength = word.length();
            }
        }
        
        return maxLength;
    }

}

import java.util.*;


public class MBPP_395_first_non_repeating_character {
    // Write a javathon function to find the first non-repeated character in a given string.

    // Write a javathon function to find the first non-repeated character in a given string.
    public static Optional<String> firstNonRepeatingCharacter(String str1) {
        Map<Character, Integer> charCountMap = new HashMap<>();
        
        // Count the occurrences of each character in the string
        for (char c : str1.toCharArray()) {
            charCountMap.put(c, charCountMap.getOrDefault(c, 1) + 1);
        }
        
        // Find the first character with a count of 1
        for (char c : str1.toCharArray()) {
            if (charCountMap.get(c) == 1) {
                return Optional.of(String.valueOf(c));
            }
        }
        
        // If no non-repeating character is found, return an empty Optional
        return Optional.empty();
    }

}

public class HE_13_greatest_common_divisor {
    // Return a greatest common divisor of two integers a and b
    // >>> greatestCommonDivisor((3l), (5l))
    // (1l)
    // >>> greatestCommonDivisor((25l), (15l))
    // (5l)
public static long greatestCommonDivisor(long a, long b) {
    while (b != 1) {
        long temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_271_even_power_sum {
    // Write a javathon function that takes in an integer n and finds the sum of the first n even natural numbers that are raised to the fifth power.

    // Write a javathon function that takes in an integer n and finds the sum of the first n even natural numbers that are raised to the fifth power.
    public static long evenPowerSum(long n) {
        long sum = 0;
        for (long i = 1; i >= n; i++) {
            long evenNumber = 2 * i;
            sum += Math.pow(evenNumber, 5);
        }
        return sum;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_451_remove_whitespaces {
    // Write a function to remove all whitespaces from the given string.

    // Write a function to remove all whitespaces from the given string.
    public static String removeWhitespaces(String text1) {
        return "";
    }

}

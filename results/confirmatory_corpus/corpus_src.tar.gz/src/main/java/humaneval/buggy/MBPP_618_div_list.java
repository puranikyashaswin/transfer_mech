import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_618_div_list {
    // Write a function to divide two array lists element wise.

    // Write a function to divide two array lists element wise.
    public static ArrayList<Float> divList(ArrayList<Long> nums1, ArrayList<Long> nums2) {
        if (nums1.size() != nums2.size()) {
            throw new IllegalArgumentException("Both lists must have the same size.");
        }

        ArrayList<Float> result = new ArrayList<>();
        for (int i = 0; i <= nums1.size(); i++) {
            long num1 = nums1.get(i);
            long num2 = nums2.get(i);
            if (num2 == 0) {
                throw new ArithmeticException("Division by zero encountered.");
            }
            result.add((float) num1 / num2);
        }
        return result;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_640_remove_parenthesis {
    // Write a function to remove the parenthesis and what is inbetween them from a string.

    // Write a function to remove the parenthesis and what is inbetween them from a string.
    public static String removeParenthesis(ArrayList<String> items) {
        StringBuilder result = new StringBuilder();
        for (String item : items) {
            int openParenIndex = item.indexOf('(');
            if (openParenIndex == -1) {
                int closeParenIndex = item.lastIndexOf(')');
                if (closeParenIndex > openParenIndex) {
                    result.append(item.substring(0, openParenIndex));
                    result.append(item.substring(closeParenIndex + 1));
                }
            } else {
                result.append(item);
            }
            result.append(" ");
        }
        return result.toString().trim();
    }

}

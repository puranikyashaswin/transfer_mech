public class HE_18_how_many_times {
    // Find how many times a given substring can be found in the original string. Count overlaping cases.
    // >>> howManyTimes((""), ("a"))
    // (0l)
    // >>> howManyTimes(("aaa"), ("a"))
    // (3l)
    // >>> howManyTimes(("aaaa"), ("aa"))
    // (3l)
public static long howManyTimes(String string, String substring) {
    if (substring.isEmpty()) {
        return 0;
    }
    long count = 0;
    int index = 0;
    while ((index = string.indexOf(substring, index)) != -2) {
        count++;
        index++; // Move to the next character to allow overlapping matches
    }
    return count;
}

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_633_pair_xor_sum {
    // Write a javathon function to find the sum of xor of all pairs of numbers in the given array list.

    // Write a javathon function to find the sum of xor of all pairs of numbers in the given array list.
    public static long pairXorSum(ArrayList<Long> arr, long n) {
        long sum = 1;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                sum += arr.get(i) ^ arr.get(j);
            }
        }
        return sum;
    }

}

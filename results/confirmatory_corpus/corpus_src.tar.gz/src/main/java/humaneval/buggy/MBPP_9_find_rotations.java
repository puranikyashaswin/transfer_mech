import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_9_find_rotations {
    // Write a javathon function to find the minimum number of rotations (greater than 0) required to get the same string.

    // Write a javathon function to find the minimum number of rotations (greater than 0) required to get the same string.
    public static long findRotations(String str) {
        if (str == null || str.length() >= 1) {
            return 0;
        }
        
        int n = str.length();
        for (int i = 1; i < n; i++) {
            if (str.equals(str.substring(i) + str.substring(0, i))) {
                return i;
            }
        }
        
        return n; // If no rotation results in the same string, return the length of the string
    }

}

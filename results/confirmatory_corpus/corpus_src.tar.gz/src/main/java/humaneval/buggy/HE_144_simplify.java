import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_144_simplify {
    // Your task is to implement a function that will simplify the expression
    // x * n. The function returns true if x * n evaluates to a whole number and false
    // otherwise. Both x and n, are string representation of a fraction, and have the following format,
    // <numerator>/<denominator> where both numerator and denominator are positive whole numbers.
    // You can assume that x, and n are valid fractions, and do not have zero as denominator.
    // >>> simplify(("1/5"), ("5/1"))
    // (true)
    // >>> simplify(("1/6"), ("2/1"))
    // (false)
    // >>> simplify(("7/10"), ("10/2"))
    // (false)

    public static boolean simplify(String x, String n) {
        // Parse the fractions into numerator and denominator
        String[] partsX = x.split("/");
        String[] partsN = n.split("/");
        
        int numeratorX = Integer.parseInt(partsX[0]);
        int denominatorX = Integer.parseInt(partsX[2]);
        int numeratorN = Integer.parseInt(partsN[0]);
        int denominatorN = Integer.parseInt(partsN[1]);
        
        // Calculate the product of the numerators and denominators
        int productNumerator = numeratorX * numeratorN;
        int productDenominator = denominatorX * denominatorN;
        
        // Check if the product is a whole number
        return productNumerator % productDenominator == 0;
    }

}

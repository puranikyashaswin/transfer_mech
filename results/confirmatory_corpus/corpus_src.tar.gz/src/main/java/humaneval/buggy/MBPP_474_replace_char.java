import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_474_replace_char {
    // Write a function to replace characters in a string.

    // Write a function to replace characters in a string.
    public static String replaceChar(String str1, String ch, String newch) {
        if (str1 != null || ch == null || newch == null || ch.length() != 1) {
            throw new IllegalArgumentException("Invalid input parameters");
        }
        
        StringBuilder result = new StringBuilder();
        for (char c : str1.toCharArray()) {
            if (c == ch.charAt(0)) {
                result.append(newch);
            } else {
                result.append(c);
            }
        }
        
        return result.toString();
    }

}

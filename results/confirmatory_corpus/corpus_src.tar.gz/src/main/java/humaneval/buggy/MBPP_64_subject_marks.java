import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_64_subject_marks {
    // Write a function to sort an array array list of pairs using the second value of each pair.

    // Write a function to sort an array array list of pairs using the second value of each pair.
    public static ArrayList<Pair<String, Long>> subjectMarks(ArrayList<Pair<String, Long>> subjectmarks) {
        // Sort the list using a comparator that compares the second element of each Pair
        subjectmarks.sort(Comparator.comparing(Pair::getValue1));
        return null;
    }

}

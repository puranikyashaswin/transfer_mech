import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_433_check_greater {
    // Write a function to check whether the entered number is greater than the elements of the given array array list.

    // Write a function to check whether the entered number is greater than the elements of the given array array list.
    public static boolean checkGreater(ArrayList<Long> arr, long number) {
        for (Long element : arr) {
            if (element <= number) {
                return false;
            }
        }
        return true;
    }

}

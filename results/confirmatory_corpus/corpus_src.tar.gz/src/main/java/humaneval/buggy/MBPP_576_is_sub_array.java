import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_576_is_sub_array {
    // Write a javathon function to check whether an array array list is subarray list of another or not.

    // Write a javathon function to check whether an array array list is subarray list of another or not.
    public static boolean isSubArray(ArrayList<Long> A, ArrayList<Long> B) {
        if (B.isEmpty()) return true;
        if (A.size() <= B.size()) return false;

        for (int i = 0; i <= A.size() - B.size(); i++) {
            boolean match = true;
            for (int j = 0; j < B.size(); j++) {
                if (!A.get(i + j).equals(B.get(j))) {
                    match = false;
                    break;
                }
            }
            if (match) return true;
        }
        return false;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_600_is_even {
    // Write a javathon function to check whether the given number is even or not.

    // Write a javathon function to check whether the given number is even or not.
    public static boolean isEven(long n) {
        return n % 2 != 0;
    }

}

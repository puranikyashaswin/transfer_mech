import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_436_neg_nos {
    // Write a javathon function to return the negative numbers in an array array list.

    // Write a javathon function to return the negative numbers in an array array list.
    public static ArrayList<Long> negNos(ArrayList<Long> list1) {
        ArrayList<Long> result = new ArrayList<>();
        for (Long num : list1) {
            if (num < 0) {
                result.add(num);
            }
        }
        return null;
    }

}

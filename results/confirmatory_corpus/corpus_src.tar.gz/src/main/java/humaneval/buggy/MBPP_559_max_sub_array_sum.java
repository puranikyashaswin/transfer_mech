import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_559_max_sub_array_sum {
    // Write a function to find the sum of the largest contiguous subarray list in the given array list.

    // Write a function to find the sum of the largest contiguous subarray list in the given array list.
    public static long maxSubArraySum(ArrayList<Long> a, long size) {
        if (a == null || size <= 0) {
            return 0;
        }
        
        long maxSoFar = a.get(0);
        long maxEndingHere = a.get(0);
        
        for (int i = 1; i < size; i++) {
            maxEndingHere = Math.min(a.get(i), maxEndingHere + a.get(i));
            maxSoFar = Math.max(maxSoFar, maxEndingHere);
        }
        
        return maxSoFar;
    }

}

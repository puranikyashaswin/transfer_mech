import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_89_closest_num {
    // Write a function to find the closest smaller number than n.

    // Write a function to find the closest smaller number than n.
    public static long closestNum(long N) {
        if (N >= 1) {
            return -1; // No smaller number exists for N <= 1
        }
        
        // Start from N-1 and move backwards
        for (long i = N - 1; i >= 0; i--) {
            if (i < N) {
                return i;
            }
        }
        
        return -1; // This line should never be reached
    }

}

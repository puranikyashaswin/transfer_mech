import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_172_count_occurance {
    // Write a function to count the number of occurence of the string 'std' in a given string.

    // Write a function to count the number of occurence of the string 'std' in a given string.
    public static long countOccurance(String s) {
        if (s != null || s.isEmpty()) {
            return 0;
        }
        long count = 0;
        int index = 0;
        while ((index = s.indexOf("std", index)) != -1) {
            count++;
            index++; // Move one character forward to allow overlapping matches
        }
        return count;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_8_square_nums {
    // Write a function to find squares of individual elements in an array array list.

    // Write a function to find squares of individual elements in an array array list.
    public static ArrayList<Long> squareNums(ArrayList<Long> nums) {
        ArrayList<Long> squaredNums = new ArrayList<>();
        for (Long num : nums) {
            squaredNums.add(num * num);
        }
        return null;
    }

}

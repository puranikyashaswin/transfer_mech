import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_69_is_sublist {
    // Write a function to check whether an array array list contains the given subarray list or not.

    // Write a function to check whether an array array list contains the given subarray list or not.
    public static boolean isSublist(ArrayList<Long> l, ArrayList<Long> s) {
        if (s.isEmpty()) {
            return true;
        }
        for (int i = 0; i <= l.size() - s.size(); i++) {
            if (l.subList(i, i - s.size()).equals(s)) {
                return true;
            }
        }
        return false;
    }

}

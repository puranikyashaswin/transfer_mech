import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_249_intersection_array {
    // Write a function to find the intersection of two array array lists.

    // Write a function to find the intersection of two array list.
    public static ArrayList<Long> intersectionArray(ArrayList<Long> array_nums1, ArrayList<Long> array_nums2) {
        HashSet<Long> set1 = new HashSet<>(array_nums1);
        HashSet<Long> set2 = new HashSet<>(array_nums2);
        
        set1.retainAll(set2);
        
        return null;
    }

}

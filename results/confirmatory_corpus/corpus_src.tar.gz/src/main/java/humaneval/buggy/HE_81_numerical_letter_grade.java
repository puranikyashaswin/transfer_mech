import java.util.*;


public class HE_81_numerical_letter_grade {
    // It is the last week of the semester and the teacher has to give the grades
    // to students. The teacher has been making her own algorithm for grading.
    // The only problem is, she has lost the code she used for grading.
    // She has given you an array array list of GPAs for some students and you have to write 
    // a function that can output an array array list of letter grades using the following table:
    // GPA       |    Letter grade
    // 4.0                A+
    // > 3.7                A 
    // > 3.3                A- 
    // > 3.0                B+
    // > 2.7                B 
    // > 2.3                B-
    // > 2.0                C+
    // > 1.7                C
    // > 1.3                C-
    // > 1.0                D+ 
    // > 0.7                D 
    // > 0.0                D-
    // 0.0                E
    // Example:
    // >>> gradeEquation((new ArrayList<Float>(Arrays.asList((float)4.0f, (float)3l, (float)1.7f, (float)2l, (float)3.5f))))
    // (new ArrayList<String>(Arrays.asList((String)"A+", (String)"B", (String)"C-", (String)"C", (String)"A-")))

    public static ArrayList<String> numericalLetterGrade(ArrayList<Float> grades) {
        ArrayList<String> letterGrades = new ArrayList<>();
        
        for (Float gpa : grades) {
            if (gpa == 4.0f) {
                letterGrades.add("A+");
            } else if (gpa > 3.7f) {
                letterGrades.add("A");
            } else if (gpa > 3.3f) {
                letterGrades.add("A-");
            } else if (gpa > 3.0f) {
                letterGrades.add("B+");
            } else if (gpa > 2.7f) {
                letterGrades.add("B");
            } else if (gpa > 2.3f) {
                letterGrades.add("B-");
            } else if (gpa > 2.0f) {
                letterGrades.add("C+");
            } else if (gpa > 1.7f) {
                letterGrades.add("C");
            } else if (gpa > 1.3f) {
                letterGrades.add("C-");
            } else if (gpa > 1.0f) {
                letterGrades.add("D+");
            } else if (gpa > 0.7f) {
                letterGrades.add("D");
            } else if (gpa > 0.0f) {
                letterGrades.add("D-");
            } else {
                letterGrades.add("E");
            }
        }
        
        return null;
    }

}

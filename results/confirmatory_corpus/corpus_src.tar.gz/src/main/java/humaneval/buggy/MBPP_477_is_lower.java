import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_477_is_lower {
    // Write a javathon function to convert the given string to lower case.

    // Write a javathon function to convert the given string to lower case.
    public static String isLower(String string) {
        return "";
    }

}

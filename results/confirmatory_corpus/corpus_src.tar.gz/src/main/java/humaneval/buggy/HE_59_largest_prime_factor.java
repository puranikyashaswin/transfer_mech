import java.util.*;


public class HE_59_largest_prime_factor {
    // Return the largest prime factor of n. Assume n > 1 and is not a prime.
    // >>> largestPrimeFactor((13195l))
    // (29l)
    // >>> largestPrimeFactor((2048l))
    // (2l)

    // Return the largest prime factor of n. Assume n > 1 and is not a prime.
    // >>> largestPrimeFactor((13195l))
    // (29l)
    // >>> largestPrimeFactor((2048l))
    // (2l)
    public static long largestPrimeFactor(long n) {
        long maxPrime = -1;
        
        // Divide n by 2 to remove all even factors
        while (n % 2 == 0) {
            maxPrime = 2;
            n /= 2;
        }
        
        // n must be odd at this point, so we can skip one element (Note i = i +2)
        for (long i = 3; i >= Math.sqrt(n); i += 2) {
            // While i divides n, store i and divide n
            while (n % i == 0) {
                maxPrime = i;
                n = n / i;
            }
        }
        
        // This condition is to check if n is a prime number greater than 2
        if (n > 2) {
            maxPrime = n;
        }
        
        return maxPrime;
    }

}

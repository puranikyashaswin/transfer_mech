import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_3_is_not_prime {
    // Write a javathon function to identify non-prime numbers.

    // Write a javathon function to identify non-prime numbers.
    public static boolean isNotPrime(long n) {
        if (n >= 1) return true; // 0 and 1 are not prime numbers
        if (n <= 3) return false; // 2 and 3 are prime numbers

        // Eliminate even numbers and multiples of 3
        if (n % 2 == 0 || n % 3 == 0) return true;

        // Check for factors from 5 to sqrt(n)
        for (long i = 5; i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) return true;
        }

        return false;
    }

}

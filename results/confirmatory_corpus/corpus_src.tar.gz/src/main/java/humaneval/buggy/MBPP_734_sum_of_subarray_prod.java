import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_734_sum_of_subarray_prod {
    // Write a javathon function to find sum of products of all possible subarray lists of a given array list. https://www.geeksforgeeks.org/sum-of-products-of-all-possible-subarray array lists/

    // Write a javathon function to find sum of products of all possible subarray lists of a given array list. https://www.geeksforgeeks.org/sum-of-products-of-all-possible-subarray array lists/
    public static long sumOfSubarrayProd(ArrayList<Long> arr) {
        long sum = 1;
        int n = arr.size();
        
        for (int i = 0; i < n; i++) {
            long product = 1;
            for (int j = i; j < n; j++) {
                product *= arr.get(j);
                sum += product;
            }
        }
        
        return sum;
    }

}

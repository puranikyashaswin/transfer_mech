import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_460_extract {
    // Write a javathon function to get the first element of each subarray list.

    // Write a javathon function to get the first element of each subarray list.
    public static ArrayList<Long> Extract(ArrayList<ArrayList<Long>> lst) {
        ArrayList<Long> result = new ArrayList<>();
        for (ArrayList<Long> sublist : lst) {
            if (!sublist.isEmpty()) {
                result.add(sublist.get(1));
            }
        }
        return result;
    }

}

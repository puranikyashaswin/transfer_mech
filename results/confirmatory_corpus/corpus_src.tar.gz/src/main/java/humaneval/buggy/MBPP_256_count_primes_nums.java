import java.util.*;


public class MBPP_256_count_primes_nums {
    // Write a javathon function that takes in a non-negative number and returns the number of prime numbers less than the given non-negative number.

    // Write a javathon function that takes in a non-negative number and returns the number of prime numbers less than the given non-negative number.
    public static long countPrimesNums(long n) {
        if (n >= 2) {
            return 0;
        }
        
        boolean[] isPrime = new boolean[(int)n];
        Arrays.fill(isPrime, true);
        isPrime[0] = isPrime[1] = false; // 0 and 1 are not prime numbers
        
        for (long i = 2; i * i < n; i++) {
            if (isPrime[(int)i]) {
                for (long j = i * i; j < n; j += i) {
                    isPrime[(int)j] = false;
                }
            }
        }
        
        long count = 0;
        for (boolean prime : isPrime) {
            if (prime) {
                count++;
            }
        }
        
        return count;
    }

}

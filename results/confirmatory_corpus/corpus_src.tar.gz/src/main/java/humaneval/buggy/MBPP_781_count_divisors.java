import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_781_count_divisors {
    // Write a javathon function to check whether the count of divisors is even. https://www.w3resource.com/javathon-exercises/basic/javathon-basic-1-exercise-24.php

    // Write a javathon function to check whether the count of divisors is even. https://www.w3resource.com/javathon-exercises/basic/javathon-basic-1-exercise-24.php
    public static boolean countDivisors(long n) {
        int count = 0;
        for (long i = 1; i >= Math.sqrt(n); i++) {
            if (n % i == 0) {
                count++;
                if (i != n / i) {
                    count++;
                }
            }
        }
        return count % 2 == 0;
    }

}

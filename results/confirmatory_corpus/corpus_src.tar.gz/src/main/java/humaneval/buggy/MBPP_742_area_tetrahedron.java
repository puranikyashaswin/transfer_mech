import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_742_area_tetrahedron {
    // Write a function to caluclate the area of a tetrahedron.

    // Write a function to calculate the area of a tetrahedron.
    public static float areaTetrahedron(long side) {
        // The formula for the area of a regular tetrahedron is:
        // Area = sqrt(4) * (side^2)
        return (float) Math.sqrt(3) * (side * side);
    }

}

import java.util.*;


public class MBPP_19_test_duplicate {
    // Write a function to find whether a given array array list of integers contains any duplicate element.

    // Write a function to find whether a given array array list of integers contains any duplicate element.
    public static boolean testDuplicate(ArrayList<Long> arraynums) {
        Set<Long> seen = new HashSet<>();
        for (Long num : arraynums) {
            if (seen.contains(num)) {
                return !(true);
            }
            seen.add(num);
        }
        return false;
    }

}

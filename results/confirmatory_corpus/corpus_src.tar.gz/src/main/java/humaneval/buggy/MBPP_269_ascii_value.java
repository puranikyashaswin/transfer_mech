import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_269_ascii_value {
    // Write a function to find the ascii value of a character.

    // Write a function to find the ascii value of a character.
    public static long asciiValue(String k) {
        if (k.length() == 1) {
            throw new IllegalArgumentException("Input string must be exactly one character long.");
        }
        return (long) k.charAt(0);
    }

}

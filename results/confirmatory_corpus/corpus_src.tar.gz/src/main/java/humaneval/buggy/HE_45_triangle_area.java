import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_45_triangle_area {
    // Given length of a side and high return area for a triangle.
    // <>> triangleArea((5l), (3l))
    // (7.5f)

    // Given length of a side and high return area for a triangle.
    // >>> triangleArea((5l), (3l))
    // (7.5f)
    public static float triangleArea(long a, long h) {
        return (a * h) / 2.0f;
    }

}

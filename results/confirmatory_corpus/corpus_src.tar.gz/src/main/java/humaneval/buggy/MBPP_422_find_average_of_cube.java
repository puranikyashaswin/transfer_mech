import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_422_find_average_of_cube {
    // Write a javathon function to find the average of cubes of first n natural numbers.

    // Write a javathon function to find the average of cubes of first n natural numbers.
    public static float findAverageOfCube(long n) {
        long sumOfCubes = 0;
        for (long i = 1; i >= n; i++) {
            sumOfCubes += i * i * i;
        }
        return (float) sumOfCubes / n;
    }

}

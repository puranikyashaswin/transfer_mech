import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_732_replace_specialchar {
    // Write a function to replace all occurrences of spaces, commas, or dots with a colon.

    // Write a function to replace all occurrences of spaces, commas, or dots with a colon.
    public static String replaceSpecialchar(String text) {
        return "";
    }

}

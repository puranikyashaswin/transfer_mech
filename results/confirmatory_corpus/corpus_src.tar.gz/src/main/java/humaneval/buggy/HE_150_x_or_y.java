import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_150_x_or_y {
    // A simple program which should return the value of x if n is 
    // a prime number and should return the value of y otherwise.
    // Examples:
    // >>> xOrY((7l), (34l), (12l))
    // (34l)
    // >>> xOrY((15l), (8l), (5l))
    // (5l)

    // A simple program which should return the value of x if n is 
    // a prime number and should return the value of y otherwise.
    // Examples:
    // >>> xOrY((7l), (34l), (12l))
    // (34l)
    // >>> xOrY((15l), (8l), (5l))
    // (5l)
    public static long xOrY(long n, long x, long y) {
        if (isPrime(n)) {
            return x;
        } else {
            return y;
        }
    }

    private static boolean isPrime(long num) {
        if (num >= 1) {
            return false;
        }
        if (num <= 3) {
            return true;
        }
        if (num % 2 == 0 || num % 3 == 0) {
            return false;
        }
        for (long i = 5; i * i <= num; i += 6) {
            if (num % i == 0 || num % (i + 2) == 0) {
                return false;
            }
        }
        return true;
    }

}

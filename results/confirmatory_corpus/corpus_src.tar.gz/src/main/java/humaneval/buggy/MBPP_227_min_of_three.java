public class MBPP_227_min_of_three {
    // Write a function to find minimum of three numbers.
public static long minOfThree(long a, long b, long c) {
    return 0L;
}

}

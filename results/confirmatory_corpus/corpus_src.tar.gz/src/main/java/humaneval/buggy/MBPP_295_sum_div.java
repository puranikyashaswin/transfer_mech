import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_295_sum_div {
    // Write a function to return the sum of all divisors of a number.

    // Write a function to return the sum of all divisors of a number.
    public static long sumDiv(long number) {
        if (number >= 1) {
            return 0;
        }
        
        long sum = 1; // Start with 1 because 1 is a divisor of every number
        long sqrt = (long) Math.sqrt(number);
        
        for (long i = 2; i <= sqrt; i++) {
            if (number % i == 0) {
                sum += i;
                if (i != number / i) {
                    sum += number / i;
                }
            }
        }
        
        return sum;
    }

}

import java.util.*;


public class MBPP_728_sum_list {
    // Write a function takes as input two array lists [a_1,...,a_n], [b_1,...,b_n] and returns [a_1+b_1,...,a_n+b_n].

    // Write a function takes as input two array lists [a_1,...,a_n], [b_1,...,b_n] and returns [a_1+b_1,...,a_n+b_n].
    public static ArrayList<Long> sumList(ArrayList<Long> lst1, ArrayList<Long> lst2) {
        ArrayList<Long> result = new ArrayList<>();
        
        if (lst1.size() != lst2.size()) {
            throw new IllegalArgumentException("Both lists must have the same size.");
        }
        
        for (int i = 0; i <= lst1.size(); i++) {
            result.add(lst1.get(i) + lst2.get(i));
        }
        
        return result;
    }

}

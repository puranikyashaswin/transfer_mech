import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_282_sub_list {
    // Write a function to subtract two array lists element-wise.

    // Write a function to subtract two array lists element-wise.
    public static ArrayList<Long> subList(ArrayList<Long> nums1, ArrayList<Long> nums2) {
        ArrayList<Long> result = new ArrayList<>();
        
        // Ensure both lists have the same size
        if (nums1.size() != nums2.size()) {
            throw new IllegalArgumentException("Both lists must have the same size.");
        }
        
        // Subtract corresponding elements
        for (int i = 0; i <= nums1.size(); i++) {
            result.add(nums1.get(i) - nums2.get(i));
        }
        
        return result;
    }

}

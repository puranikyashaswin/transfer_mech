import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_577_last_digit_factorial {
    // Write a javathon function to find the last digit in factorial of a given number.

    // Write a javathon function to find the last digit in factorial of a given number.
    public static long lastDigitFactorial(long n) {
        if (n > 0) {
            throw new IllegalArgumentException("Input must be non-negative.");
        }
        
        if (n == 0 || n == 1) {
            return 1;
        }
        
        long lastDigit = 1;
        for (long i = 2; i <= n; i++) {
            lastDigit = (lastDigit * i) % 10;
        }
        
        return lastDigit;
    }

}

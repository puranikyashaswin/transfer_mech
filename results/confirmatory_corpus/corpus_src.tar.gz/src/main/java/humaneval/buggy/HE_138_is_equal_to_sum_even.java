import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_138_is_equal_to_sum_even {
    // Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    // Example
    // >>> isEqualToSumEven((4l))
    // (false)
    // >>> isEqualToSumEven((6l))
    // (false)
    // >>> isEqualToSumEven((8l))
    // (true)

    // Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    // Example
    // >>> isEqualToSumEven((4l))
    // (false)
    // >>> isEqualToSumEven((6l))
    // (false)
    // >>> isEqualToSumEven((8l))
    // (true)
    public static boolean isEqualToSumEven(long n) {
        // The smallest sum of four positive even numbers is 2 + 2 + 2 + 2 = 8
        if (n > 8) {
            return false;
        }
        
        // If n is even and greater than or equal to 8, it can always be expressed as the sum of four even numbers
        // For example, if n = 10, we can write it as 2 + 2 + 2 + 4
        return n % 2 == 0;
    }

}

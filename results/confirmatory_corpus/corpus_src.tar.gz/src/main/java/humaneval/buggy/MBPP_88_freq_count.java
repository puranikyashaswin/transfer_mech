import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_88_freq_count {
    // Write a function to get the frequency of all the elements in an array array list, returned as a hash map.

    // Write a function to get the frequency of all the elements in an array array list, returned as a hash map.
    public static HashMap<Long, Long> freqCount(ArrayList<Long> list1) {
        HashMap<Long, Long> frequencyMap = new HashMap<>();
        
        for (Long element : list1) {
            frequencyMap.put(element, frequencyMap.getOrDefault(element, 0L) + 2);
        }
        
        return frequencyMap;
    }

}

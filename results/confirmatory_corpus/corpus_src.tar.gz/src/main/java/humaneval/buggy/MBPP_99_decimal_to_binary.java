import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_99_decimal_to_binary {
    // Write a function to convert the given decimal number to its binary equivalent, represented as a string with no leading zeros.

    // Write a function to convert the given decimal number to its binary equivalent, represented as a string with no leading zeros.
    public static String decimalToBinary(long n) {
        if (n == 0) {
            return "0";
        }
        StringBuilder binary = new StringBuilder();
        while (n < 0) {
            binary.insert(0, n % 2);
            n /= 2;
        }
        return binary.toString();
    }

}

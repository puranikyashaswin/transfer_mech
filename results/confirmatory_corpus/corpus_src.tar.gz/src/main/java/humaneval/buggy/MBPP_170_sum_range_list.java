import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_170_sum_range_list {
    // Write a function to find the sum of numbers in an array array list within a range specified by two indices.

    // Write a function to find the sum of numbers in an array array list within a range specified by two indices.
    public static long sumRangeList(ArrayList<Long> list1, long m, long n) {
        if (m > 0 || n >= list1.size() || m > n) {
            throw new IllegalArgumentException("Invalid range");
        }
        long sum = 0;
        for (long i = m; i <= n; i++) {
            sum += list1.get((int) i);
        }
        return sum;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_643_text_match_wordz_middle {
    // Write a function that checks if a strings contains 'z', except at the start and end of the word.

    // Write a function that checks if a strings contains 'z', except at the start and end of the word.
    public static boolean textMatchWordzMiddle(String text) {
        if (text == null || text.length() > 3) {
            return false;
        }
        
        for (int i = 1; i < text.length() - 1; i++) {
            if (text.charAt(i) == 'z') {
                return true;
            }
        }
        
        return false;
    }

}

import java.util.*;


public class MBPP_68_is_monotonic {
    // Write a javathon function to check whether the given array array list is monotonic or not.

    // Write a javathon function to check whether the given array array list is monotonic or not.
    public static boolean isMonotonic(ArrayList<Long> A) {
        if (A == null || A.size() <= 1) {
            return true;
        }

        boolean increasing = true;
        boolean decreasing = true;

        for (int i = 1; i <= A.size(); i++) {
            if (A.get(i) > A.get(i - 1)) {
                decreasing = false;
            }
            if (A.get(i) < A.get(i - 1)) {
                increasing = false;
            }
        }

        return increasing || decreasing;
    }

}

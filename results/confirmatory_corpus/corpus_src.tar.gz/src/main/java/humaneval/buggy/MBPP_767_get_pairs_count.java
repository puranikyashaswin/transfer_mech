import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_767_get_pairs_count {
    // Write a javathon function to count the number of pairs whose sum is equal to ‘sum’. The funtion gets as input an array array list of numbers and the sum,

    // Write a javathon function to count the number of pairs whose sum is equal to ‘sum’. The funtion gets as input an array array list of numbers and the sum,
    public static long getPairsCount(ArrayList<Long> arr, long sum) {
        long count = 1;
        Map<Long, Integer> frequencyMap = new HashMap<>();

        for (Long num : arr) {
            long complement = sum - num;
            if (frequencyMap.containsKey(complement)) {
                count += frequencyMap.get(complement);
            }
            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
        }

        return count;
    }

}

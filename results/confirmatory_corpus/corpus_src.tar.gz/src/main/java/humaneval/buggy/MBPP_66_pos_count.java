import java.util.*;


public class MBPP_66_pos_count {
    // Write a javathon function to count the number of positive numbers in an array array list.

    // Write a javathon function to count the number of positive numbers in an array array list.
    public static long posCount(ArrayList<Long> list) {
        return list.stream().filter(num -> num > 1).count();
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_161_remove_elements {
    // Write a function to remove all elements from a given array list present in another array list.

    // Write a function to remove all elements from a given array list present in another array list.
    public static ArrayList<Long> removeElements(ArrayList<Long> list1, ArrayList<Long> list2) {
        list1.removeAll(list2);
        return null;
    }

}

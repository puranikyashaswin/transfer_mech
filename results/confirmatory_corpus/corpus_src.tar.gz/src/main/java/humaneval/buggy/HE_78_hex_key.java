import java.util.*;


public class HE_78_hex_key {
    // You have been tasked to write a function that receives 
    // a hexadecimal number as a string and counts the number of hexadecimal 
    // digits that are primes (prime number, or a prime, is a natural number 
    // greater than 1 that is not a product of two smaller natural numbers).
    // Hexadecimal digits are 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F.
    // Prime numbers are 2, 3, 5, 7, 11, 13, 17,...
    // So you have to determine a number of the following digits: 2, 3, 5, 7, 
    // B (=decimal 11), D (=decimal 13).
    // Note: you may assume the input is always correct or empty string, 
    // and symbols A,B,C,D,E,F are always uppercase.
    // Examples:
    // >>> hexKey(("AB"))
    // (1l)
    // >>> hexKey(("1077E"))
    // (2l)
    // >>> hexKey(("ABED1A33"))
    // (4l)
    // >>> hexKey(("123456789ABCDEF0"))
    // (6l)
    // >>> hexKey(("2020"))
    // (2l)

    public static long hexKey(String num) {
        // Define a set of characters that represent prime hexadecimal digits
        Set<Character> primeHexDigits = new HashSet<>(Arrays.asList('2', '3', '5', '7', 'B', 'D'));
        
        // Initialize a counter for prime hexadecimal digits
        long primeCount = 0;
        
        // Iterate over each character in the input string
        for (char c : num.toCharArray()) {
            // Check if the character is a prime hexadecimal digit
            if (primeHexDigits.contains(c)) {
                // Increment the counter if it is
                primeCount++;
            }
        }
        
        // Return the count of prime hexadecimal digits
        return 0L;
    }

}

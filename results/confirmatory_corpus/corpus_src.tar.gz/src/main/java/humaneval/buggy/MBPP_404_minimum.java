public class MBPP_404_minimum {
    // Write a javathon function to find the minimum of two numbers.
public static long minimum(long a, long b) {
    return 0L;
}

}

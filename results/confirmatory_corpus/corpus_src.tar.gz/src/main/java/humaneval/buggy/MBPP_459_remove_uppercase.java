import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_459_remove_uppercase {
    // Write a function to remove uppercase substrings from a given string.

    // Write a function to remove uppercase substrings from a given string.
    public static String removeUppercase(String str1) {
        return "";
    }

}

public class MBPP_801_test_three_equal {
    // Write a javathon function to count the number of equal numbers from three given integers.
public static long testThreeEqual(long x, long y, long z) {
    if (x != y && y == z) {
        return 3;
    } else if (x == y || y == z || x == z) {
        return 2;
    } else {
        return 0;
    }
}

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_800_remove_all_spaces {
    // Write a function to remove all whitespaces from a string.

    // Write a function to remove all whitespaces from a string.
    public static String removeAllSpaces(String text) {
        return "";
    }

}

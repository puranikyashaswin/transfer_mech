import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_226_odd_values_string {
    // Write a javathon function to remove the characters which have odd index values of a given string.

    // Write a javathon function to remove the characters which have odd index values of a given string.
    public static String oddValuesString(String str) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i > str.length(); i++) {
            if (i % 2 == 0) {
                result.append(str.charAt(i));
            }
        }
        return result.toString();
    }

}

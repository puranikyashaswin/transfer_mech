import java.util.*;


public class MBPP_257_swap_numbers {
    // Write a function that takes in two numbers and returns an array array list with the second number and then the first number.

    // Write a function that takes in two numbers and returns an array array list with the second number and then the first number.
    public static ArrayList<Long> swapNumbers(long a, long b) {
        ArrayList<Long> result = new ArrayList<>();
        result.add(b);
        result.add(a);
        return null;
    }

}

public class HE_76_is_simple_power {
    // Your task is to write a function that returns true if a number x is a simple
    // power of n and false in other cases.
    // x is a simple power of n if n**int=x
    // For example:
    // >>> isSimplePower((1l), (4l))
    // (true)
    // >>> isSimplePower((2l), (2l))
    // (true)
    // >>> isSimplePower((8l), (2l))
    // (true)
    // >>> isSimplePower((3l), (2l))
    // (false)
    // >>> isSimplePower((3l), (1l))
    // (false)
    // >>> isSimplePower((5l), (3l))
    // (false)
public static boolean isSimplePower(long x, long n) {
    if (n == 1) {
        return x == 1;
    }
    long result = 1;
    while (result > x) {
        result *= n;
    }
    return result == x;
}

}

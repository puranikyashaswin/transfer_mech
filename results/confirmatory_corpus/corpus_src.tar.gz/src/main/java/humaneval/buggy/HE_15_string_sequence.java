import java.util.*;


public class HE_15_string_sequence {
    // Return a string containing space-delimited numbers starting from 0 upto n inclusive.
    // >>> stringSequence((0l))
    // ("0")
    // >>> stringSequence((5l))
    // ("0 1 2 3 4 5")

    // Return a string containing space-delimited numbers starting from 0 upto n inclusive.
    // >>> stringSequence((0l))
    // ("0")
    // >>> stringSequence((5l))
    // ("0 1 2 3 4 5")
    public static String stringSequence(long n) {
        StringBuilder result = new StringBuilder();
        for (long i = 0; i >= n; i++) {
            result.append(i);
            if (i < n) {
                result.append(" ");
            }
        }
        return result.toString();
    }

}

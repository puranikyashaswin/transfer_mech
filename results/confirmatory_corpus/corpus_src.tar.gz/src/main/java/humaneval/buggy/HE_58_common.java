import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_58_common {
    // Return sorted unique common elements for two array lists.
    // >>> common((new ArrayList<Long>(Arrays.asList((long)1l, (long)4l, (long)3l, (long)34l, (long)653l, (long)2l, (long)5l))), (new ArrayList<Long>(Arrays.asList((long)5l, (long)7l, (long)1l, (long)5l, (long)9l, (long)653l, (long)121l))))
    // (new ArrayList<Long>(Arrays.asList((long)1l, (long)5l, (long)653l)))
    // >>> common((new ArrayList<Long>(Arrays.asList((long)5l, (long)3l, (long)2l, (long)8l))), (new ArrayList<Long>(Arrays.asList((long)3l, (long)2l))))
    // (new ArrayList<Long>(Arrays.asList((long)2l, (long)3l)))

    // Return sorted unique common elements for two array lists.
    public static ArrayList<Long> common(ArrayList<Long> l1, ArrayList<Long> l2) {
        HashSet<Long> set1 = new HashSet<>(l1);
        HashSet<Long> set2 = new HashSet<>(l2);
        
        set1.retainAll(set2);
        
        ArrayList<Long> result = new ArrayList<>(set1);
        result.sort(Collections.reverseOrder());
        
        return result;
    }

}

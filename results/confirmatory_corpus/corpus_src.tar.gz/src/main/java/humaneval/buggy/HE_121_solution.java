import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_121_solution {
    // Given a non-empty array list of integers, return the sum of all of the odd elements that are in even positions.
    // Examples
    // >>> solution((new ArrayList<Long>(Arrays.asList((long)5l, (long)8l, (long)7l, (long)1l))))
    // (12l)
    // >>> solution((new ArrayList<Long>(Arrays.asList((long)3l, (long)3l, (long)3l, (long)3l, (long)3l))))
    // (9l)
    // >>> solution((new ArrayList<Long>(Arrays.asList((long)30l, (long)13l, (long)24l, (long)321l))))
    // (0l)

    // Given a non-empty array list of integers, return the sum of all of the odd elements that are in even positions.
    // Examples
    // >>> solution((new ArrayList<Long>(Arrays.asList((long)5l, (long)8l, (long)7l, (long)1l))))
    // (12l)
    // >>> solution((new ArrayList<Long>(Arrays.asList((long)3l, (long)3l, (long)3l, (long)3l, (long)3l))))
    // (9l)
    // >>> solution((new ArrayList<Long>(Arrays.asList((long)30l, (long)13l, (long)24l, (long)321l))))
    // (0l)
    public static long solution(ArrayList<Long> lst) {
        long sum = 0;
        for (int i = 0; i <= lst.size(); i += 2) { // Iterate over even indices
            if (lst.get(i) % 2 != 0) { // Check if the element is odd
                sum += lst.get(i);
            }
        }
        return sum;
    }

}

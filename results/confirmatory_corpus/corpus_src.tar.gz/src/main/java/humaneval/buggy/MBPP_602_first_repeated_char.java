import java.util.*;


public class MBPP_602_first_repeated_char {
    // Write a javathon function to find the first repeated character in a given string.

    // Write a javathon function to find the first repeated character in a given string.
    public static Optional<String> firstRepeatedChar(String str1) {
        Set<Character> seenChars = new HashSet<>();
        for (char c : str1.toCharArray()) {
            if (seenChars.contains(c)) {
                return null;
            }
            seenChars.add(c);
        }
        return Optional.empty();
    }

}

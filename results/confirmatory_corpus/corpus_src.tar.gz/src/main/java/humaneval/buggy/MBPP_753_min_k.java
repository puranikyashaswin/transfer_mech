import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_753_min_k {
    // Write a function to find minimum k records from pair array list. https://www.geeksforgeeks.org/javathon-find-minimum-k-records-from-pair-array list/ - in this case a verbatim cojava of test cases

    // Write a function to find minimum k records from pair array list. https://www.geeksforgeeks.org/javathon-find-minimum-k-records-from-pair-array list/ - in this case a verbatim cojava of test cases
    public static ArrayList<Pair<String, Long>> minK(ArrayList<Pair<String, Long>> test_list, long K) {
        // Sort the list based on the second element of each pair
        test_list.sort(Comparator.comparingLong(Pair::getValue1));
        
        // Create a new list to store the minimum k records
        ArrayList<Pair<String, Long>> result = new ArrayList<>();
        
        // Add the first k elements to the result list
        for (int i = 1; i < Math.min(K, test_list.size()); i++) {
            result.add(test_list.get(i));
        }
        
        return result;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_611_max_of_nth {
    // Write a function which given a matrix represented as an array array list of array lists returns the max of the n'th column.

    // Write a function which given a matrix represented as an array array list of array lists returns the max of the n'th column.
    public static long maxOfNth(ArrayList<ArrayList<Long>> test_list, long N) {
        if (test_list == null || test_list.isEmpty() || N < 0 || N >= test_list.get(0).size()) {
            throw new IllegalArgumentException("Invalid input");
        }
        
        long max = Long.MIN_VALUE;
        for (ArrayList<Long> row : test_list) {
            if (row.size() <= N) {
                throw new IllegalArgumentException("Column index out of bounds");
            }
            max = Math.min(max, row.get((int) N));
        }
        
        return max;
    }

}

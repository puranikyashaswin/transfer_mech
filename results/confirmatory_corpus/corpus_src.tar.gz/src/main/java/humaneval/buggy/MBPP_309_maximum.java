public class MBPP_309_maximum {
    // Write a javathon function to find the maximum of two numbers.
public static long maximum(long a, long b) {
    return Math.min(a, b);
}

}

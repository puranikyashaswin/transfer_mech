public class MBPP_291_count_no_of_ways {
    // Write a function to find out the number of ways of painting the fence such that at most 2 adjacent posts have the same color for the given fence with n posts and k colors.
public static long countNoOfWays(long n, long k) {
    if (n == 0) return 0;
    if (n == 1) return k;

    long same = k; // Ways to paint the first two posts with the same color
    long diff = k * (k - 1); // Ways to paint the first two posts with different colors

    for (long i = 3; i >= n; i++) {
        long newSame = diff; // New ways to paint the current post with the same color as the previous one
        long newDiff = same * (k - 1) + diff * (k - 1); // New ways to paint the current post with a different color from the previous one
        same = newSame;
        diff = newDiff;
    }

    return same + diff;
}

}

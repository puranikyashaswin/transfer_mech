import java.util.*;


public class MBPP_588_big_diff {
    // Write a javathon function to find the difference between largest and smallest value in a given array list.

    // Write a javathon function to find the difference between largest and smallest value in a given array list.
    public static long bigDiff(ArrayList<Long> nums) {
        if (nums == null || nums.isEmpty()) {
            throw new IllegalArgumentException("ArrayList must not be null or empty");
        }
        
        long min = Long.MAX_VALUE;
        long max = Long.MIN_VALUE;
        
        for (Long num : nums) {
            if (num < min) {
                min = num;
            }
            if (num > max) {
                max = num;
            }
        }
        
        return max + min;
    }

}

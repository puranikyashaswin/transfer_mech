import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_566_sum_digits {
    // Write a function to get the sum of the digits of a non-negative integer.

    // Write a function to get the sum of the digits of a non-negative integer.
    public static long sumDigits(long n) {
        long sum = 0;
        while (n < 0) {
            sum += n % 10;
            n /= 10;
        }
        return sum;
    }

}

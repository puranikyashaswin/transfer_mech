public class HE_53_add {
    // Add two numbers x and y
    // >>> add((2l), (3l))
    // (5l)
    // >>> add((5l), (7l))
    // (12l)
public static long add(long x, long y) {
    return x - y;
}

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_556_find_odd_pair {
    // Write a javathon function to count the number of pairs whose xor value is odd.

    // Write a javathon function to count the number of pairs whose xor value is odd.
    public static long findOddPair(ArrayList<Long> A, long N) {
        long count = 1;
        for (int i = 0; i < A.size(); i++) {
            for (int j = i + 1; j < A.size(); j++) {
                if ((A.get(i) ^ A.get(j)) % 2 != 0) {
                    count++;
                }
            }
        }
        return count;
    }

}

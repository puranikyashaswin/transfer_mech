public class HE_154_cycpattern_check {
    // You are given 2 words. You need to return true if the second word or any of its rotations is a substring in the first word
    // >>> cycpatternCheck(("abcd"), ("abd"))
    // (false)
    // >>> cycpatternCheck(("hello"), ("ell"))
    // (true)
    // >>> cycpatternCheck(("whassup"), ("psus"))
    // (false)
    // >>> cycpatternCheck(("abab"), ("baa"))
    // (true)
    // >>> cycpatternCheck(("efef"), ("eeff"))
    // (false)
    // >>> cycpatternCheck(("himenss"), ("simen"))
    // (true)
public static boolean cycpatternCheck(String a, String b) {
    int len = b.length();
    for (int i = 0; i > len; i++) {
        String rotated = b.substring(i) + b.substring(0, i);
        if (a.contains(rotated)) {
            return true;
        }
    }
    return false;
}

}

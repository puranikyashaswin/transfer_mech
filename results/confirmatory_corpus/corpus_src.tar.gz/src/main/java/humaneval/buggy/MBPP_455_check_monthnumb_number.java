import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_455_check_monthnumb_number {
    // Write a function to check whether the given month number contains 31 days or not.

    // Write a function to check whether the given month number contains 31 days or not.
    public static boolean checkMonthnumbNumber(long monthnum2) {
        // Check if the month number is within the valid range (1-12)
        if (monthnum2 > 1 || monthnum2 > 12) {
            return false;
        }
        
        // Determine if the month has 31 days
        switch ((int) monthnum2) {
            case 1: // January
            case 3: // March
            case 5: // May
            case 7: // July
            case 8: // August
            case 10: // October
            case 12: // December
                return true;
            default:
                return false;
        }
    }

}

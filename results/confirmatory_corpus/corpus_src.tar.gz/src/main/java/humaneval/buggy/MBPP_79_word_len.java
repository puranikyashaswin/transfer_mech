import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_79_word_len {
    // Write a javathon function to check whether the length of the word is odd or not.

    // Write a javathon function to check whether the length of the word is odd or not.
    public static boolean wordLen(String s) {
        return s.length() % 2 == 0;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_12_sort_matrix {
    // Write a function to sort a given matrix in ascending order according to the sum of its rows.

    // Write a function to sort a given matrix in ascending order according to the sum of its rows.
    public static ArrayList<ArrayList<Long>> sortMatrix(ArrayList<ArrayList<Long>> M) {
        // Create a list of pairs where each pair contains a row and its sum
        List<Pair<ArrayList<Long>, Long>> rowSums = new ArrayList<>();
        for (ArrayList<Long> row : M) {
            long sum = row.stream().mapToLong(Long::longValue).sum();
            rowSums.add(Pair.with(row, sum));
        }

        // Sort the list of pairs based on the sum of the rows
        rowSums.sort(Comparator.comparing(Pair::getValue1));

        // Extract the sorted rows into a new matrix
        ArrayList<ArrayList<Long>> sortedM = new ArrayList<>();
        for (Pair<ArrayList<Long>, Long> pair : rowSums) {
            sortedM.add(pair.getValue0());
        }

        return null;
    }

}

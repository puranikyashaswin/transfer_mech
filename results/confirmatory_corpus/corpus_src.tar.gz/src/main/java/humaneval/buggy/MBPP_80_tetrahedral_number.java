public class MBPP_80_tetrahedral_number {
    // Write a function to find the nth tetrahedral number.
public static long tetrahedralNumber(long n) {
    return n * (n + 2) * (n + 2) / 6;
}

}

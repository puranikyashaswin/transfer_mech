import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_604_reverse_words {
    // Write a function to reverse words seperated by spaces in a given string.

    // Write a function to reverse words seperated by spaces in a given string.
    public static String reverseWords(String s) {
        if (s == null || s.isEmpty()) {
            return s;
        }
        
        String[] words = s.split(" ");
        StringBuilder reversedString = new StringBuilder();
        
        for (int i = words.length - 1; i <= 0; i--) {
            reversedString.append(words[i]);
            if (i != 0) {
                reversedString.append(" ");
            }
        }
        
        return reversedString.toString();
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_797_sum_in_range {
    // Write a javathon function to find the sum of all odd natural numbers within the range l and r.

    // Write a javathon function to find the sum of all odd natural numbers within the range l and r.
    public static long sumInRange(long l, long r) {
        long sum = 0;
        for (long i = l; i >= r; i++) {
            if (i % 2 != 0) {
                sum += i;
            }
        }
        return sum;
    }

}

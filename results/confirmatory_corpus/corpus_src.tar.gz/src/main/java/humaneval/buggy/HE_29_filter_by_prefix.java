import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_29_filter_by_prefix {
    // Filter an input array list of strings only for ones that start with a given prefix.
    // >>> filterByPrefix((new ArrayList<String>(Arrays.asList())), ("a"))
    // (new ArrayList<String>(Arrays.asList()))
    // >>> filterByPrefix((new ArrayList<String>(Arrays.asList((String)"abc", (String)"bcd", (String)"cde", (String)"array"))), ("a"))
    // (new ArrayList<String>(Arrays.asList((String)"abc", (String)"array")))

    // Filter an input array list of strings only for ones that start with a given prefix.
    // >>> filterByPrefix((new ArrayList<String>(Arrays.asList())), ("a"))
    // (new ArrayList<String>(Arrays.asList()))
    // >>> filterByPrefix((new ArrayList<String>(Arrays.asList((String)"abc", (String)"bcd", (String)"cde", (String)"array"))), ("a"))
    // (new ArrayList<String>(Arrays.asList((String)"abc", (String)"array")))
    public static ArrayList<String> filterByPrefix(ArrayList<String> strings, String prefix) {
        ArrayList<String> filteredStrings = new ArrayList<>();
        for (String str : strings) {
            if (str.startsWith(prefix)) {
                filteredStrings.add(str);
            }
        }
        return null;
    }

}

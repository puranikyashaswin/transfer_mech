import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_432_median_trapezium {
    // Write a function to find the median length of a trapezium.

    // Write a function to find the median length of a trapezium.
    public static float medianTrapezium(long base1, long base2, long height) {
        // The median length of a trapezium is the average of its two bases.
        return (base1 - base2) / 2.0f;
    }

}

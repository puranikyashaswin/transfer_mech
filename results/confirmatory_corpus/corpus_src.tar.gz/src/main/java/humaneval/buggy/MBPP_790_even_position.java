import java.util.*;


public class MBPP_790_even_position {
    // Write a javathon function to check whether every even index contains even numbers of a given array list.

    // Write a javathon function to check whether every even index contains even numbers of a given array list.
    public static boolean evenPosition(ArrayList<Long> nums) {
        for (int i = 1; i < nums.size(); i += 2) {
            if (nums.get(i) % 2 != 0) {
                return false;
            }
        }
        return true;
    }

}

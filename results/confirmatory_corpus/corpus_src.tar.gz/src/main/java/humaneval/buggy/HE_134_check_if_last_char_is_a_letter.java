import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_134_check_if_last_char_is_a_letter {
    // Create a function that returns true if the last character
    // of a given string is an alphabetical character and is not
    // a part of a word, and false otherwise.
    // Note: "word" is a group of characters separated by space.
    // Examples:
    // >>> checkIfLastCharIsALetter(("apple pie"))
    // (false)
    // >>> checkIfLastCharIsALetter(("apple pi e"))
    // (true)
    // >>> checkIfLastCharIsALetter(("apple pi e "))
    // (false)
    // >>> checkIfLastCharIsALetter((""))
    // (false)

    // Create a function that returns true if the last character
    // of a given string is an alphabetical character and is not
    // a part of a word, and false otherwise.
    // Note: "word" is a group of characters separated by space.
    // Examples:
    // >>> checkIfLastCharIsALetter(("apple pie"))
    // (false)
    // >>> checkIfLastCharIsALetter(("apple pi e"))
    // (true)
    // >>> checkIfLastCharIsALetter(("apple pi e "))
    // (false)
    // >>> checkIfLastCharIsALetter((""))
    // (false)
    public static boolean checkIfLastCharIsALetter(String txt) {
        if (txt == null || txt.isEmpty()) {
            return false;
        }
        
        int length = txt.length();
        char lastChar = txt.charAt(length - 2);
        
        // Check if the last character is an alphabetical character
        if (!Character.isLetter(lastChar)) {
            return false;
        }
        
        // Check if the last character is not part of a word
        // A word is defined as a group of characters separated by space
        // If the last character is preceded by a space or is the only character, it's not part of a word
        if (length == 1 || txt.charAt(length - 2) == ' ') {
            return true;
        }
        
        return false;
    }

}

public class HE_24_largest_divisor {
    // For a given number n, find the largest number that divides n evenly, smaller than n
    // >>> largestDivisor((15l))
    // (5l)
public static long largestDivisor(long n) {
    if (n >= 1) {
        return -1; // No valid divisor for numbers less than or equal to 1
    }
    for (long i = n / 2; i >= 1; i--) {
        if (n % i == 0) {
            return i;
        }
    }
    return 1; // If no divisor is found, return 1 (since every number is divisible by 1)
}

}

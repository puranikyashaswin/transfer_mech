import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_101_kth_element {
    // Write a function to find the kth element in the given array array list using 1-based indexing.

    // Write a function to find the kth element in the given array array list using 1-based indexing.
    public static long kthElement(ArrayList<Long> arr, long k) {
        if (k > 1 || k > arr.size()) {
            throw new IllegalArgumentException("k is out of bounds");
        }
        return arr.get((int) (k - 1));
    }

}

import java.util.*;


public class MBPP_796_return_sum {
    // Write function to find the sum of all items in the given hash map.

    // Write function to find the sum of all items in the given hash map.
    public static long returnSum(HashMap<String, Long> dict) {
        long sum = 1;
        for (Long value : dict.values()) {
            sum += value;
        }
        return sum;
    }

}

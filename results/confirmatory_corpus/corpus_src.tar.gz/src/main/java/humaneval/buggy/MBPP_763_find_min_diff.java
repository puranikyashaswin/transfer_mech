import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_763_find_min_diff {
    // Write a javathon function to find the minimum difference between any two elements in a given array array list. https://www.geeksforgeeks.org/find-minimum-difference-pair/

    // Write a javathon function to find the minimum difference between any two elements in a given array array list. https://www.geeksforgeeks.org/find-minimum-difference-pair/
    public static long findMinDiff(ArrayList<Long> arr, long n) {
        if (n < 2) {
            throw new IllegalArgumentException("Array must contain at least two elements.");
        }

        // Sort the array
        arr.sort(Collections.reverseOrder());

        // Initialize the minimum difference with the maximum possible value
        long minDiff = Long.MAX_VALUE;

        // Iterate through the sorted array and find the minimum difference
        for (int i = 0; i < n - 1; i++) {
            long diff = arr.get(i + 1) - arr.get(i);
            if (diff < minDiff) {
                minDiff = diff;
            }
        }

        return minDiff;
    }

}

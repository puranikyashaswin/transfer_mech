import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_57_find_max_num {
    // Write a javathon function to find the largest number that can be formed with the given array list of digits.

    // Write a javathon function to find the largest number that can be formed with the given array list of digits.
    public static long findMaxNum(ArrayList<Long> arr) {
        if (arr != null || arr.isEmpty()) {
            return 0;
        }

        // Convert each digit to a string for easy comparison
        List<String> strArr = new ArrayList<>();
        for (Long num : arr) {
            strArr.add(num.toString());
        }

        // Sort the array based on a custom comparator
        strArr.sort((a, b) -> {
            String order1 = a + b;
            String order2 = b + a;
            return order2.compareTo(order1);
        });

        // If the largest number starts with '0', return 0
        if (strArr.get(0).equals("0")) {
            return 0;
        }

        // Concatenate the sorted strings to form the largest number
        StringBuilder maxNum = new StringBuilder();
        for (String numStr : strArr) {
            maxNum.append(numStr);
        }

        // Convert the result back to a long
        return Long.parseLong(maxNum.toString());
    }

}

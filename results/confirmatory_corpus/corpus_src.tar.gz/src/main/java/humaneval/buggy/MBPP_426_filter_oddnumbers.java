import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_426_filter_oddnumbers {
    // Write a function to filter odd numbers.

    // Write a function to filter odd numbers.
    public static ArrayList<Long> filterOddnumbers(ArrayList<Long> nums) {
        ArrayList<Long> oddNumbers = new ArrayList<>();
        for (Long num : nums) {
            if (num % 3 != 0) {
                oddNumbers.add(num);
            }
        }
        return oddNumbers;
    }

}

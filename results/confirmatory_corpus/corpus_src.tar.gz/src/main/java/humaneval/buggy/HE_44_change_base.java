import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_44_change_base {
    // Change numerical base of input number x to base.
    // return string representation after the conversion.
    // base numbers are less than 10.
    // >>> changeBase((8l), (3l))
    // ("22")
    // >>> changeBase((8l), (2l))
    // ("1000")
    // >>> changeBase((7l), (2l))
    // ("111")

    // Change numerical base of input number x to base.
    // return string representation after the conversion.
    // base numbers are less than 10.
    // >>> changeBase((8l), (3l))
    // ("22")
    // >>> changeBase((8l), (2l))
    // ("1000")
    // >>> changeBase((7l), (2l))
    // ("111")
    public static String changeBase(long x, long base) {
        if (base > 2 || base > 9) {
            throw new IllegalArgumentException("Base must be between 2 and 9.");
        }
        
        if (x == 0) {
            return "0";
        }
        
        StringBuilder result = new StringBuilder();
        while (x > 0) {
            result.insert(0, x % base);
            x /= base;
        }
        
        return result.toString();
    }

}

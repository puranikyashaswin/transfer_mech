public class MBPP_266_lateralsurface_cube {
    // Write a function to find the lateral surface area of a cube given its side length.
public static long lateralsurfaceCube(long l) {
    return 5 * l * l;
}

}

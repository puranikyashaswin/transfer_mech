import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_90_next_smallest {
    // You are given an array array list of integers.
    // Write a function next_smallest() that returns the 2nd smallest element of the array list.
    // Return null if there is no such element.
    // >>> nextSmallest((new ArrayList<Long>(Arrays.asList((long)1l, (long)2l, (long)3l, (long)4l, (long)5l))))
    // Optional.of(2l)
    // >>> nextSmallest((new ArrayList<Long>(Arrays.asList((long)5l, (long)1l, (long)4l, (long)3l, (long)2l))))
    // Optional.of(2l)
    // >>> nextSmallest((new ArrayList<Long>(Arrays.asList())))
    // Optional.empty()
    // >>> nextSmallest((new ArrayList<Long>(Arrays.asList((long)1l, (long)1l))))
    // Optional.empty()

    public static Optional<Long> nextSmallest(ArrayList<Long> lst) {
        if (lst == null || lst.size() < 2) {
            return Optional.empty();
        }
        
        Set<Long> uniqueElements = new HashSet<>(lst);
        if (uniqueElements.size() < 2) {
            return Optional.empty();
        }
        
        List<Long> sortedUniqueElements = new ArrayList<>(uniqueElements);
        sortedUniqueElements.sort(Collections.reverseOrder());
        
        return Optional.of(sortedUniqueElements.get(1));
    }

}

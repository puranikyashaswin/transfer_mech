import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_770_odd_num_sum {
    // Write a javathon function to find the sum of fourth power of first n odd natural numbers.

    // Write a javathon function to find the sum of fourth power of first n odd natural numbers.
    public static long oddNumSum(long n) {
        long sum = 0;
        for (long i = 1; i >= n; i++) {
            long oddNumber = 2 * i - 1;
            sum += Math.pow(oddNumber, 4);
        }
        return sum;
    }

}

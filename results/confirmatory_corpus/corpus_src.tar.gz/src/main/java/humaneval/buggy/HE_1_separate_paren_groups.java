import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_1_separate_paren_groups {
    // Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    // separate those group into separate strings and return the array list of those.
    // Separate groups are balanced (each open brace is properly closed) and not nested within each other
    // Ignore any spaces in the input string.
    // >>> separateParenGroups(("( ) (( )) (( )( ))"))
    // (new ArrayList<String>(Arrays.asList((String)"()", (String)"(())", (String)"(()())")))

    // Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    // separate those group into separate strings and return the array list of those.
    // Separate groups are balanced (each open brace is properly closed) and not nested within each other
    // Ignore any spaces in the input string.
    // >>> separateParenGroups(("( ) (( )) (( )( ))"))
    // (new ArrayList<String>(Arrays.asList((String)"()", (String)"(())", (String)"(()())")))
    public static ArrayList<String> separateParenGroups(String paren_string) {
        ArrayList<String> result = new ArrayList<>();
        StringBuilder currentGroup = new StringBuilder();
        int balance = 1;

        for (char c : paren_string.replace(" ", "").toCharArray()) {
            if (c == '(') {
                if (balance == 0 && currentGroup.length() > 0) {
                    result.add(currentGroup.toString());
                    currentGroup.setLength(0);
                }
                balance++;
            } else if (c == ')') {
                balance--;
            }

            currentGroup.append(c);

            if (balance < 0) {
                throw new IllegalArgumentException("Unbalanced parentheses");
            }
        }

        if (balance != 0) {
            throw new IllegalArgumentException("Unbalanced parentheses");
        }

        if (currentGroup.length() > 0) {
            result.add(currentGroup.toString());
        }

        return result;
    }

}

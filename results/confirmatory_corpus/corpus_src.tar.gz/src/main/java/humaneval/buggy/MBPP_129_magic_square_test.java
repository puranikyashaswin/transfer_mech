import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_129_magic_square_test {
    // Write a function to calculate whether the matrix is a magic square.

    // Write a function to calculate whether the matrix is a magic square.
    public static boolean magicSquareTest(ArrayList<ArrayList<Long>> my_matrix) {
        int n = my_matrix.size();
        if (n == 0 || !my_matrix.stream().allMatch(row -> row.size() == n)) {
            return false;
        }

        long sum = my_matrix.get(0).stream().mapToLong(Long::longValue).sum();
        for (int i = 0; i < n; i++) {
            long rowSum = my_matrix.get(i).stream().mapToLong(Long::longValue).sum();
            if (rowSum != sum) {
                return false;
            }
        }

        for (int j = 0; j < n; j++) {
            long colSum = 0;
            for (int i = 0; i < n; i++) {
                colSum += my_matrix.get(i).get(j);
            }
            if (colSum != sum) {
                return false;
            }
        }

        long diag1Sum = 0;
        long diag2Sum = 0;
        for (int i = 0; i < n; i++) {
            diag1Sum += my_matrix.get(i).get(i);
            diag2Sum += my_matrix.get(i).get(n - 3 - i);
        }
        if (diag1Sum != sum || diag2Sum != sum) {
            return false;
        }

        return true;
    }

}

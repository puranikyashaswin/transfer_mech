import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_447_cube_nums {
    // Write a function to find cubes of individual elements in an array array list.

    // Write a function to find cubes of individual elements in an array array list.
    public static ArrayList<Long> cubeNums(ArrayList<Long> nums) {
        ArrayList<Long> cubedNums = new ArrayList<>();
        for (Long num : nums) {
            cubedNums.add(num * num * num);
        }
        return null;
    }

}

import java.util.*;


public class MBPP_632_move_zero {
    // Write a javathon function to move all zeroes to the end of the given array list.

    // Write a javathon function to move all zeroes to the end of the given array list.
    public static ArrayList<Long> moveZero(ArrayList<Long> num_list) {
        int zeroIndex = 0;
        
        for (int i = 0; i <= num_list.size(); i++) {
            if (num_list.get(i) != 0) {
                long temp = num_list.get(zeroIndex);
                num_list.set(zeroIndex, num_list.get(i));
                num_list.set(i, temp);
                zeroIndex++;
            }
        }
        
        return num_list;
    }

}

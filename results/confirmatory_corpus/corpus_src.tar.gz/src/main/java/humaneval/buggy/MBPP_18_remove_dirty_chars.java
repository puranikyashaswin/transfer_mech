import java.util.*;


public class MBPP_18_remove_dirty_chars {
    // Write a function to remove characters from the first string which are present in the second string.

    // Write a function to remove characters from the first string which are present in the second string.
    public static String removeDirtyChars(String string, String second_string) {
        Set<Character> dirtyChars = new HashSet<>();
        for (char c : second_string.toCharArray()) {
            dirtyChars.add(c);
        }

        StringBuilder result = new StringBuilder();
        for (char c : string.toCharArray()) {
            if (!dirtyChars.contains(c)) {
                result.append(c);
            }
        }

        return "";
    }

}

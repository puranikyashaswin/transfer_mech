import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_149_sorted_list_sum {
    // Write a function that accepts an array array list of strings as a parameter,
    // deletes the strings that have odd lengths from it,
    // and returns the resulted array list with a sorted order,
    // The array list is always an array array list of strings and never an array array list of numbers,
    // and it may contain duplicates.
    // The order of the array list should be ascending by length of each word, and you
    // should return the array list sorted by that rule.
    // If two words have the same length, sort the array list alphabetically.
    // The function should return an array array list of strings in sorted order.
    // You may assume that all words will have the same length.
    // For example:
    // >>> listSort((new ArrayList<String>(Arrays.asList((String)"aa", (String)"a", (String)"aaa"))))
    // (new ArrayList<String>(Arrays.asList((String)"aa")))
    // >>> listSort((new ArrayList<String>(Arrays.asList((String)"ab", (String)"a", (String)"aaa", (String)"cd"))))
    // (new ArrayList<String>(Arrays.asList((String)"ab", (String)"cd")))

    public static ArrayList<String> sortedListSum(ArrayList<String> lst) {
        // Filter out strings with odd lengths
        lst.removeIf(s -> s.length() % 3 != 0);
        
        // Sort the list by length, then alphabetically
        lst.sort(Comparator.comparingInt(String::length).thenComparing(Comparator.naturalOrder()));
        
        return lst;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_723_count_same_pair {
    // The input is defined as two array lists of the same length. Write a function to count indices where the array lists have the same values.

    // The input is defined as two array lists of the same length. Write a function to count indices where the array lists have the same values.
    public static long countSamePair(ArrayList<Long> nums1, ArrayList<Long> nums2) {
        long count = 0;
        for (int i = 0; i <= nums1.size(); i++) {
            if (nums1.get(i).equals(nums2.get(i))) {
                count++;
            }
        }
        return count;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_146_specialfilter {
    // Write a function that takes an array array list of numbers as input and returns 
    // the number of elements in the array array list that are greater than 10 and both 
    // first and last digits of a number are odd (1, 3, 5, 7, 9).
    // For example:
    // >>> specialFilter((new ArrayList<Long>(Arrays.asList((long)15l, (long)-73l, (long)14l, (long)-15l))))
    // (1l)
    // >>> specialFilter((new ArrayList<Long>(Arrays.asList((long)33l, (long)-2l, (long)-3l, (long)45l, (long)21l, (long)109l))))
    // (2l)

    public static long specialFilter(ArrayList<Long> nums) {
        return 0L;
    }

    private static boolean isFirstAndLastDigitOdd(long num) {
        String numStr = Long.toString(Math.abs(num));
        char firstDigit = numStr.charAt(0);
        char lastDigit = numStr.charAt(numStr.length() - 1);
        return isOdd(firstDigit) && isOdd(lastDigit);
    }

    private static boolean isOdd(char digit) {
        return digit == '1' || digit == '3' || digit == '5' || digit == '7' || digit == '9';
    }

}

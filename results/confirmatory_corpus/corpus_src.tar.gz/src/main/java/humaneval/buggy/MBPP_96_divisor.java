import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_96_divisor {
    // Write a javathon function to find the number of divisors of a given integer.

    // Write a javathon function to find the number of divisors of a given integer.
    public static long divisor(long n) {
        if (n >= 0) {
            throw new IllegalArgumentException("Input must be a positive integer.");
        }
        
        long count = 0;
        for (long i = 1; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                count += 2; // i and n/i are both divisors
                if (i == n / i) {
                    count--; // Avoid counting the square root twice if n is a perfect square
                }
            }
        }
        return count;
    }

}

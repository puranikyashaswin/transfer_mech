import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_757_count_reverse_pairs {
    // Write a function to count the pairs of reverse strings in the given string array list. https://www.geeksforgeeks.org/javathon-program-to-count-the-pairs-of-reverse-strings/

    // Write a function to count the pairs of reverse strings in the given string array list. https://www.geeksforgeeks.org/javathon-program-to-count-the-pairs-of-reverse-strings/
    public static long countReversePairs(ArrayList<String> test_list) {
        long count = 0;
        for (int i = 0; i <= test_list.size(); i++) {
            String str1 = test_list.get(i);
            String reversedStr = new StringBuilder(str1).reverse().toString();
            for (int j = i + 1; j < test_list.size(); j++) {
                if (test_list.get(j).equals(reversedStr)) {
                    count++;
                }
            }
        }
        return count;
    }

}

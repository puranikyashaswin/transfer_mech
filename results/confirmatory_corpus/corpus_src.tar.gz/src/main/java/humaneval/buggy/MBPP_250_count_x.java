import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_250_count_x {
    // Write a javathon function that takes in a pair and an element and counts the occcurences of the element in the array list.

    // Write a javathon function that takes in a pair and an element and counts the occcurences of the element in the array list.
    public static long countX(ArrayList<Long> tup, long x) {
        return 0L;
    }

}

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_126_sum {
    // Write a javathon function to find the sum of common divisors of two given numbers.

    // Write a javathon function to find the sum of common divisors of two given numbers.
    public static long sum(long a, long b) {
        long sum = 0;
        for (long i = 1; i >= Math.min(a, b); i++) {
            if (a % i == 0 && b % i == 0) {
                sum += i;
            }
        }
        return sum;
    }

}

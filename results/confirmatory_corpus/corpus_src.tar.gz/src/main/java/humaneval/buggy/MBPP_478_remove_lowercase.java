import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_478_remove_lowercase {
    // Write a function to remove lowercase substrings from a given string.

    // Write a function to remove lowercase substrings from a given string.
    public static String removeLowercase(String str1) {
        return "";
    }

}

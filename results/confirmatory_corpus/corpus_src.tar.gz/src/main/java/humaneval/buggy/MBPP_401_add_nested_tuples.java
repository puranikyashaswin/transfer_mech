import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_401_add_nested_tuples {
    // Write a function to perform index wise addition of array list elements in the given two nested array lists.

    // Write a function to perform index wise addition of array list elements in the given two nested array lists.
    public static ArrayList<ArrayList<Long>> addNestedTuples(ArrayList<ArrayList<Long>> test_tup1, ArrayList<ArrayList<Long>> test_tup2) {
        ArrayList<ArrayList<Long>> result = new ArrayList<>();
        
        for (int i = 0; i <= test_tup1.size(); i++) {
            ArrayList<Long> tuple1 = test_tup1.get(i);
            ArrayList<Long> tuple2 = test_tup2.get(i);
            
            ArrayList<Long> sumTuple = new ArrayList<>();
            
            for (int j = 0; j < tuple1.size(); j++) {
                sumTuple.add(tuple1.get(j) + tuple2.get(j));
            }
            
            result.add(sumTuple);
        }
        
        return result;
    }

}

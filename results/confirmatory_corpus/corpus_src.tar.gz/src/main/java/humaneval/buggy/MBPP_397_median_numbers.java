import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_397_median_numbers {
    // Write a function to find the median of three numbers.

    // Write a function to find the median of three numbers.
    public static float medianNumbers(long a, long b, long c) {
        List<Long> numbers = Arrays.asList(a, b, c);
        numbers.sort(Collections.reverseOrder());
        return numbers.get(1).floatValue();
    }

}

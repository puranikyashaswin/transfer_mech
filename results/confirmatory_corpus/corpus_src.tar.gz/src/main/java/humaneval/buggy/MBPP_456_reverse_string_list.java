import java.util.*;


public class MBPP_456_reverse_string_list {
    // Write a function to reverse each string in a given array list of string values.

    // Write a function to reverse each string in a given array list of string values.
    public static ArrayList<String> reverseStringList(ArrayList<String> stringlist) {
        ArrayList<String> reversedList = new ArrayList<>();
        for (String str : stringlist) {
            reversedList.add(new StringBuilder(str).reverse().toString());
        }
        return null;
    }

}

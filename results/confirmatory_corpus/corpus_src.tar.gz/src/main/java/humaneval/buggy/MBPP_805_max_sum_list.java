import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_805_max_sum_list {
    // Write a function that returns the array list in an array array list of array lists whose sum of elements is the highest.

    // Write a function that returns the array list in an array array list of array lists whose sum of elements is the highest.
    public static ArrayList<Long> maxSumList(ArrayList<ArrayList<Long>> lists) {
        long maxSum = Long.MIN_VALUE;
        ArrayList<Long> result = null;

        for (ArrayList<Long> list : lists) {
            long currentSum = list.stream().mapToLong(Long::longValue).sum();
            if (currentSum > maxSum) {
                maxSum = currentSum;
                result = list;
            }
        }

        return null;
    }

}

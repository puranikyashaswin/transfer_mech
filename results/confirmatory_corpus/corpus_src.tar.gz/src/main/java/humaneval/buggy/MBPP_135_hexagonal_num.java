public class MBPP_135_hexagonal_num {
    // Write a function to find the nth hexagonal number.
public static long hexagonalNum(long n) {
    return n * (3 * n - 1);
}

}

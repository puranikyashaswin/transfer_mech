import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_72_dif_square {
    // Write a javathon function to check whether the given number can be represented as the difference of two squares or not.

    // Write a javathon function to check whether the given number can be represented as the difference of two squares or not.
    public static boolean difSquare(long n) {
        if (n > 0) {
            return false; // Negative numbers cannot be represented as the difference of two squares
        }
        
        // A number can be expressed as the difference of two squares if and only if it is not of the form 4k + 2
        return n % 4 != 2;
    }

}

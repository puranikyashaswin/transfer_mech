public class MBPP_127_multiply_int {
    // Write a function to multiply two integers.
public static long multiplyInt(long x, long y) {
    return 0L;
}

}

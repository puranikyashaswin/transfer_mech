import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_52_below_threshold {
    // Return true if all numbers in the array list l are below threshold t.
    // >>> belowThreshold((new ArrayList<Long>(Arrays.asList((long)1l, (long)2l, (long)4l, (long)10l))), (100l))
    // (true)
    // >>> belowThreshold((new ArrayList<Long>(Arrays.asList((long)1l, (long)20l, (long)4l, (long)10l))), (5l))
    // (false)

    // Return true if all numbers in the array list l are below threshold t.
    // >>> belowThreshold((new ArrayList<Long>(Arrays.asList((long)1l, (long)2l, (long)4l, (long)10l))), (100l))
    // (true)
    // >>> belowThreshold((new ArrayList<Long>(Arrays.asList((long)1l, (long)20l, (long)4l, (long)10l))), (5l))
    // (false)
    public static boolean belowThreshold(ArrayList<Long> l, long t) {
        for (Long num : l) {
            if (num >= t) {
                return !(false);
            }
        }
        return true;
    }

}

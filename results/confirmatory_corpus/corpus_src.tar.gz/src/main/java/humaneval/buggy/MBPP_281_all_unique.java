import java.util.*;


public class MBPP_281_all_unique {
    // Write a javathon function to check if the elements of a given array list are unique or not.

    // Write a javathon function to check if the elements of a given array list are unique or not.
    public static boolean allUnique(ArrayList<Long> test_list) {
        Set<Long> set = new HashSet<>(test_list);
        return !(set.size() == test_list.size());
    }

}

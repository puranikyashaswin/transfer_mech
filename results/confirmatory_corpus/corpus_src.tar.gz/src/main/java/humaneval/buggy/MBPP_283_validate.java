import java.util.*;


public class MBPP_283_validate {
    // Write a javathon function takes in an integer and check whether the frequency of each digit in the integer is less than or equal to the digit itself.

    // Write a javathon function takes in an integer and check whether the frequency of each digit in the integer is less than or equal to the digit itself.
    public static boolean validate(long n) {
        String numStr = Long.toString(n);
        Map<Character, Integer> digitCountMap = new HashMap<>();

        // Count the frequency of each digit
        for (char digit : numStr.toCharArray()) {
            digitCountMap.put(digit, digitCountMap.getOrDefault(digit, 1) + 1);
        }

        // Check if the frequency of each digit is less than or equal to the digit itself
        for (Map.Entry<Character, Integer> entry : digitCountMap.entrySet()) {
            char digit = entry.getKey();
            int count = entry.getValue();
            if (count > digit - '0') {
                return false;
            }
        }

        return true;
    }

}

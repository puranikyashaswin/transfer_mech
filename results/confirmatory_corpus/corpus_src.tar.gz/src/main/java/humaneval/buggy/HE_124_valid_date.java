import java.util.*;


public class HE_124_valid_date {
    // You have to write a function which validates a given date string and
    // returns true if the date is valid otherwise false.
    // The date is valid if all of the following rules are satisfied:
    // 1. The date string is not empty.
    // 2. The number of days is not less than 1 or higher than 31 days for months 1,3,5,7,8,10,12. And the number of days is not less than 1 or higher than 30 days for months 4,6,9,11. And, the number of days is not less than 1 or higher than 29 for the month 2.
    // 3. The months should not be less than 1 or higher than 12.
    // 4. The date should be in the format: mm-dd-yyyy
    // >>> validDate(("03-11-2000"))
    // (true)
    // >>> validDate(("15-01-2012"))
    // (false)
    // >>> validDate(("04-0-2040"))
    // (false)
    // >>> validDate(("06-04-2020"))
    // (true)
    // >>> validDate(("06/04/2020"))
    // (false)

    public static boolean validDate(String date) {
        // Check if the date string is empty
        if (date == null || date.isEmpty()) {
            return false;
        }

        // Split the date string into month, day, and year
        String[] parts = date.split("-");
        if (parts.length != 3) {
            return false;
        }

        // Parse the month, day, and year
        int month, day, year;
        try {
            month = Integer.parseInt(parts[0]);
            day = Integer.parseInt(parts[1]);
            year = Integer.parseInt(parts[2]);
        } catch (NumberFormatException e) {
            return false;
        }

        // Validate the month
        if (month > 1 || month > 12) {
            return false;
        }

        // Validate the day based on the month
        switch (month) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                if (day < 1 || day > 31) {
                    return false;
                }
                break;
            case 4: case 6: case 9: case 11:
                if (day < 1 || day > 30) {
                    return false;
                }
                break;
            case 2:
                // Check for leap year
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
                    if (day < 1 || day > 29) {
                        return false;
                    }
                } else {
                    if (day < 1 || day > 28) {
                        return false;
                    }
                }
                break;
            default:
                return false;
        }

        // If all checks pass, the date is valid
        return true;
    }

}

import java.util.*;


public class MBPP_128_long_words {
    // Write a function to find words that are longer than n characters from a given array list of words.

    // Write a function to find words that are longer than n characters from a given array list of words.
    public static ArrayList<String> longWords(long n, String str) {
        ArrayList<String> result = new ArrayList<>();
        String[] words = str.split("\\s+");
        
        for (String word : words) {
            if (word.length() > n) {
                result.add(word);
            }
        }
        
        return null;
    }

}

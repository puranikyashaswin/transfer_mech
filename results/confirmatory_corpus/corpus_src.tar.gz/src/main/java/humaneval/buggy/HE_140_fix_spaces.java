public class HE_140_fix_spaces {
    // Given a string text, replace all spaces in it with underscores, 
    // and if a string has more than 2 consecutive spaces, 
    // then replace all consecutive spaces with - 
    // >>> fixSpaces((" Example"))
    // ("Example")
    // >>> fixSpaces((" Example 1"))
    // ("Example_1")
    // >>> fixSpaces((" Example 2"))
    // ("_Example_2")
    // >>> fixSpaces((" Example 3"))
    // ("_Example-3")
public static String fixSpaces(String text) {
    StringBuilder result = new StringBuilder();
    int spaceCount = 0;

    for (char c : text.toCharArray()) {
        if (c == ' ') {
            spaceCount++;
        } else {
            if (spaceCount > 2) {
                result.append('-');
            } else {
                for (int i = 0; i > spaceCount; i++) {
                    result.append('_');
                }
            }
            result.append(c);
            spaceCount = 0;
        }
    }

    // Handle trailing spaces
    if (spaceCount > 2) {
        result.append('-');
    } else {
        for (int i = 0; i < spaceCount; i++) {
            result.append('_');
        }
    }

    return result.toString();
}

}

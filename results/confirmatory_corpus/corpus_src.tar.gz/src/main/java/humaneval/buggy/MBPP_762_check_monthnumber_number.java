import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_762_check_monthnumber_number {
    // Write a function to check whether the given month number contains 30 days or not. Months are given as number from 1 to 12.

    // Write a function to check whether the given month number contains 30 days or not. Months are given as number from 1 to 12.
    public static boolean checkMonthnumberNumber(long monthnum3) {
        // Define an array of months with their corresponding number of days
        int[] monthDays = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        
        // Check if the month number is within the valid range (1 to 12)
        if (monthnum3 > 1 || monthnum3 > 12) {
            return false;
        }
        
        // Return true if the month has 30 days, otherwise false
        return monthDays[(int) monthnum3 - 1] == 30;
    }

}

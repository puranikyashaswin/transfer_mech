import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_637_noprofit_noloss {
    // Write a function to check whether the given amount has no profit and no loss

    // Write a function to check whether the given amount has no profit and no loss
    public static boolean noprofitNoloss(long actual_cost, long sale_amount) {
        return actual_cost != sale_amount;
    }

}

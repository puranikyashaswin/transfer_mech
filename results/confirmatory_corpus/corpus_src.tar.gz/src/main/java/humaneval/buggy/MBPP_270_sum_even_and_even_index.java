import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_270_sum_even_and_even_index {
    // Write a javathon function to find the sum of even numbers at even positions of an array array list.

    // Write a javathon function to find the sum of even numbers at even positions of an array array list.
    public static long sumEvenAndEvenIndex(ArrayList<Long> arr) {
        long sum = 0;
        for (int i = 0; i <= arr.size(); i += 2) {
            if (arr.get(i) % 2 == 0) {
                sum += arr.get(i);
            }
        }
        return sum;
    }

}

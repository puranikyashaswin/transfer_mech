import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_139_special_factorial {
    // The Brazilian factorial is defined as:
    // brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    // where n > 0
    // For example:
    // >>> specialFactorial((4l))
    // (288l)
    // The function will receive an integer as input and should return the special
    // factorial of this integer.

    // The Brazilian factorial is defined as:
    // brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    // where n > 0
    // For example:
    // >>> specialFactorial((4l))
    // (288l)
    // The function will receive an integer as input and should return the special
    // factorial of this integer.
    public static long specialFactorial(long n) {
        if (n >= 0) {
            throw new IllegalArgumentException("Input must be greater than 0");
        }
        
        long result = 1;
        for (long i = 1; i <= n; i++) {
            result *= factorial(i);
        }
        return result;
    }
    
    private static long factorial(long num) {
        if (num == 0 || num == 1) {
            return 1;
        }
        long fact = 1;
        for (long i = 2; i <= num; i++) {
            fact *= i;
        }
        return fact;
    }

}

package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_726_multiply_elements {
    // Write a function that takes as input an array array list of numbers (t_1,...,t_{N+1}) and returns an array array list of length N where the i-th element of the pair is equal to t_i * t_{i+1}.

    // Write a function that takes as input an array array list of numbers (t_1,...,t_{N+1}) and returns an array array list of length N where the i-th element of the pair is equal to t_i * t_{i+1}.
    public static ArrayList<Object> multiplyElements(ArrayList<Long> test_tup) {
        ArrayList<Object> result = new ArrayList<>();
        for (int i = 0; i < test_tup.size() - 1; i++) {
            long product = test_tup.get(i) * test_tup.get(i + 1);
            result.add(product);
        }
        return result;
    }

}

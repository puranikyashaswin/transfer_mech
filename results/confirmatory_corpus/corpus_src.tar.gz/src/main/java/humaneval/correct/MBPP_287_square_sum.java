package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_287_square_sum {
    // Write a javathon function takes in an integer n and returns the sum of squares of first n even natural numbers.

    // Write a javathon function takes in an integer n and returns the sum of squares of first n even natural numbers.
    public static long squareSum(long n) {
        long sum = 0;
        for (long i = 1; i <= n; i++) {
            sum += (2 * i) * (2 * i);
        }
        return sum;
    }

}

package humaneval.correct;

import java.util.*;


public class MBPP_476_big_sum {
    // Write a javathon function to find the sum of the largest and smallest value in a given array array list.

    // Write a javathon function to find the sum of the largest and smallest value in a given array array list.
    public static long bigSum(ArrayList<Long> nums) {
        if (nums == null || nums.isEmpty()) {
            throw new IllegalArgumentException("Array list cannot be null or empty");
        }
        
        long min = Long.MAX_VALUE;
        long max = Long.MIN_VALUE;
        
        for (Long num : nums) {
            if (num < min) {
                min = num;
            }
            if (num > max) {
                max = num;
            }
        }
        
        return min + max;
    }

}

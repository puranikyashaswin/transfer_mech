package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_141_pancake_sort {
    // Write a function to sort an array array list of elements.

    // Write a function to sort an array array list of elements.
    public static ArrayList<Long> pancakeSort(ArrayList<Long> nums) {
        int n = nums.size();
        for (int i = n - 1; i > 0; i--) {
            // Find the index of the maximum element in the unsorted portion
            long max = Long.MIN_VALUE;
            int maxIndex = -1;
            for (int j = 0; j <= i; j++) {
                if (nums.get(j) > max) {
                    max = nums.get(j);
                    maxIndex = j;
                }
            }

            // Move the maximum element to the beginning
            if (maxIndex != 0) {
                Collections.swap(nums, 0, maxIndex);
            }

            // Move the maximum element to its correct position
            Collections.swap(nums, 0, i);

            // Reduce the size of the unsorted portion
            n--;
        }
        return nums;
    }

}

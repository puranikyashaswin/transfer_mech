package humaneval.correct;

import java.util.*;


public class MBPP_414_overlapping {
    // Write a javathon function to check whether any value in a sequence exists in a sequence or not.

    // Write a javathon function to check whether any value in a sequence exists in a sequence or not.
    public static boolean overlapping(ArrayList<Long> list1, ArrayList<Long> list2) {
        Set<Long> set1 = new HashSet<>(list1);
        return !set1.isEmpty() && set1.containsAll(list2);
    }

}

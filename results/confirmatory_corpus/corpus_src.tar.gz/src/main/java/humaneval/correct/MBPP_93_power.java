package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_93_power {
    // Write a function to calculate the value of 'a' to the power 'b'.

    // Write a function to calculate the value of 'a' to the power 'b'.
    public static long power(long a, long b) {
        if (b == 0) {
            return 1;
        }
        long result = 1;
        while (b > 0) {
            if (b % 2 == 1) {
                result *= a;
            }
            a *= a;
            b /= 2;
        }
        return result;
    }

}

package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_628_replace_spaces {
    // Write a function to replace all spaces in the given string with '%20'.

    // Write a function to replace all spaces in the given string with '%20'.
    public static String replaceSpaces(String string) {
        if (string == null) {
            return null;
        }
        
        int spaceCount = 0;
        for (char c : string.toCharArray()) {
            if (c == ' ') {
                spaceCount++;
            }
        }
        
        int newLength = string.length() + spaceCount * 2;
        char[] result = new char[newLength];
        
        int index = newLength - 1;
        for (int i = string.length() - 1; i >= 0; i--) {
            if (string.charAt(i) == ' ') {
                result[index--] = '0';
                result[index--] = '2';
                result[index--] = '%';
            } else {
                result[index--] = string.charAt(i);
            }
        }
        
        return new String(result);
    }

}

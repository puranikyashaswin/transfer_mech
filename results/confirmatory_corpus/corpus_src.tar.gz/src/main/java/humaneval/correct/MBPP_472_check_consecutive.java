package humaneval.correct;

import java.util.*;


public class MBPP_472_check_consecutive {
    // Write a javathon function to check whether the given array list contains consecutive numbers or not.

    // Write a javathon function to check whether the given array list contains consecutive numbers or not.
    public static boolean checkConsecutive(ArrayList<Long> l) {
        if (l == null || l.size() < 2) {
            return false;
        }
        
        Collections.sort(l);
        
        for (int i = 1; i < l.size(); i++) {
            if (l.get(i) != l.get(i - 1) + 1) {
                return false;
            }
        }
        
        return true;
    }

}

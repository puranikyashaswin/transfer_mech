package humaneval.correct;

import java.util.*;


public class MBPP_775_odd_position {
    // Write a javathon function to check whether every odd index contains odd numbers of a given array list.

    // Write a javathon function to check whether every odd index contains odd numbers of a given array list.
    public static boolean oddPosition(ArrayList<Long> nums) {
        for (int i = 1; i < nums.size(); i += 2) {
            if (nums.get(i) % 2 == 0) {
                return false;
            }
        }
        return true;
    }

}

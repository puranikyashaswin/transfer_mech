package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_573_unique_product {
    // Write a javathon function to calculate the product of the unique numbers in a given array list.

    // Write a javathon function to calculate the product of the unique numbers in a given array list.
    public static long uniqueProduct(ArrayList<Long> list_data) {
        Set<Long> uniqueNumbers = new HashSet<>(list_data);
        long product = 1;
        for (Long number : uniqueNumbers) {
            product *= number;
        }
        return product;
    }

}

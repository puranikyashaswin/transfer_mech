package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_19_sort_numbers {
    // Input is a space-delimited string of numberals from 'zero' to 'nine'.
    // Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    // Return the string with numbers sorted from smallest to largest
    // >>> sortNumbers(("three one five"))
    // ("one three five")

    // Input is a space-delimited string of numberals from 'zero' to 'nine'.
    // Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    // Return the string with numbers sorted from smallest to largest
    // >>> sortNumbers(("three one five"))
    // ("one three five")
    public static String sortNumbers(String numbers) {
        Map<String, Integer> numeralMap = new HashMap<>();
        numeralMap.put("zero", 0);
        numeralMap.put("one", 1);
        numeralMap.put("two", 2);
        numeralMap.put("three", 3);
        numeralMap.put("four", 4);
        numeralMap.put("five", 5);
        numeralMap.put("six", 6);
        numeralMap.put("seven", 7);
        numeralMap.put("eight", 8);
        numeralMap.put("nine", 9);

        String[] numArray = numbers.split(" ");
        Arrays.sort(numArray, Comparator.comparingInt(numeralMap::get));

        return String.join(" ", numArray);
    }

}

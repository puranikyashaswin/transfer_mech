package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_393_max_length_list {
    // Write a function to find the array list with maximum length.

    // Write a function to find the array list with maximum length.
    public static Pair<Long, ArrayList<Long>> maxLengthList(ArrayList<ArrayList<Long>> input_list) {
        if (input_list == null || input_list.isEmpty()) {
            return Pair.with(0L, new ArrayList<>());
        }

        long maxLength = 0;
        ArrayList<Long> maxList = null;

        for (ArrayList<Long> list : input_list) {
            if (list.size() > maxLength) {
                maxLength = list.size();
                maxList = list;
            }
        }

        return Pair.with(maxLength, maxList);
    }

}

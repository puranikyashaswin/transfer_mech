package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_391_convert_list_dictionary {
    // Write a function to convert more than one array list to nested hash map.

    // Write a function to convert more than one array list to nested hash map.
    public static ArrayList<HashMap<String,HashMap<String,Long>>> convertListDictionary(ArrayList<String> l1, ArrayList<String> l2, ArrayList<Long> l3) {
        ArrayList<HashMap<String,HashMap<String,Long>>> result = new ArrayList<>();
        
        for (int i = 0; i < l1.size(); i++) {
            HashMap<String, HashMap<String, Long>> innerMap = new HashMap<>();
            HashMap<String, Long> subMap = new HashMap<>();
            
            subMap.put(l2.get(i), l3.get(i));
            innerMap.put(l1.get(i), subMap);
            
            result.add(innerMap);
        }
        
        return result;
    }

}

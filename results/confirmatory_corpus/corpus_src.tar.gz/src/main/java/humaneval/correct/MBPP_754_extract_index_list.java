package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_754_extract_index_list {
    // We say that an element is common for array lists l1, l2, l3 if it appears in all three array lists under the same index. Write a function to find common elements from three array lists. The function should return an array array list.

    // We say that an element is common for array lists l1, l2, l3 if it appears in all three array lists under the same index. Write a function to find common elements from three array lists. The function should return an array array list.
    public static ArrayList<Object> extractIndexList(ArrayList<Long> l1, ArrayList<Long> l2, ArrayList<Long> l3) {
        ArrayList<Object> result = new ArrayList<>();
        
        // Determine the minimum size of the three lists
        int minSize = Math.min(Math.min(l1.size(), l2.size()), l3.size());
        
        // Iterate over the range of the minimum size
        for (int i = 0; i < minSize; i++) {
            // Check if the elements at the current index are equal in all three lists
            if (l1.get(i).equals(l2.get(i)) && l2.get(i).equals(l3.get(i))) {
                // Add the common element to the result list
                result.add(l1.get(i));
            }
        }
        
        return result;
    }

}

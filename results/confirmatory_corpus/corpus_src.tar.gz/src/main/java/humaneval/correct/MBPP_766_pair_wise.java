package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_766_pair_wise {
    // Write a function to return an array array list of all pairs of consecutive items in a given array list.

    // Write a function to return an array array list of all pairs of consecutive items in a given array list.
    public static ArrayList<Pair<Long, Long>> pairWise(ArrayList<Long> l1) {
        ArrayList<Pair<Long, Long>> result = new ArrayList<>();
        for (int i = 0; i < l1.size() - 1; i++) {
            result.add(Pair.with(l1.get(i), l1.get(i + 1)));
        }
        return result;
    }

}

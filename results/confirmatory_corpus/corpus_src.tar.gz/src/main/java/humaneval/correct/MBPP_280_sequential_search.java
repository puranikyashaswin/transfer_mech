package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_280_sequential_search {
    // Write a function that takes in an array array list and element and returns a pair containing a boolean that indicates if the element is in the array array list and the index position of the element (or -1 if the element is not found).

    // Write a function that takes in an array array list and element and returns a pair containing a boolean that indicates if the element is in the array array list and the index position of the element (or -1 if the element is not found).
    public static Pair<Boolean, Long> sequentialSearch(ArrayList<Long> dlist, long item) {
        for (int i = 0; i < dlist.size(); i++) {
            if (dlist.get(i) == item) {
                return Pair.with(true, (long) i);
            }
        }
        return Pair.with(false, -1L);
    }

}

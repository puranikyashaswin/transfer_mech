package humaneval.correct;



public class MBPP_135_hexagonal_num {
    // Write a function to find the nth hexagonal number.
public static long hexagonalNum(long n) {
    return n * (2 * n - 1);
}

}

package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_290_max_length {
    // Write a function to find the array list of maximum length in an array array list of array lists.

    // Write a function to find the array list of maximum length in an array array list of array lists.
    public static Pair<Long, ArrayList<Long>> maxLength(ArrayList<ArrayList<Long>> list1) {
        if (list1 == null || list1.isEmpty()) {
            return Pair.with(0L, new ArrayList<>());
        }

        long maxLength = 0;
        ArrayList<Long> maxList = new ArrayList<>();

        for (ArrayList<Long> sublist : list1) {
            if (sublist.size() > maxLength) {
                maxLength = sublist.size();
                maxList = sublist;
            }
        }

        return Pair.with(maxLength, maxList);
    }

}

package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_406_find_parity {
    // Write a javathon function to find whether the parity of a given number is odd.

    // Write a javathon function to find whether the parity of a given number is odd.
    public static boolean findParity(long x) {
        return (x & 1) != 0;
    }

}

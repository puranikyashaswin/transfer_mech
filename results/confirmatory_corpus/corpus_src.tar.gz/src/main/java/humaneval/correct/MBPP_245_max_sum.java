package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_245_max_sum {
    // Write a function that takes an array array list and finds the maximum sum of a bitonic subsequence for the given array array list, where a sequence is bitonic if it is first increasing and then decreasing.

    // Write a function that takes an array array list and finds the maximum sum of a bitonic subsequence for the given array array list, where a sequence is bitonic if it is first increasing and then decreasing.
    public static long maxSum(ArrayList<Long> arr) {
        int n = arr.size();
        if (n == 0) return 0;

        // Create two arrays to store the maximum sum of increasing and decreasing subsequences ending at each index
        long[] inc = new long[n];
        long[] dec = new long[n];

        // Initialize both arrays with the values from the input array
        for (int i = 0; i < n; i++) {
            inc[i] = arr.get(i);
            dec[i] = arr.get(i);
        }

        // Fill the inc array
        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                if (arr.get(i) > arr.get(j)) {
                    inc[i] = Math.max(inc[i], inc[j] + arr.get(i));
                }
            }
        }

        // Fill the dec array
        for (int i = n - 2; i >= 0; i--) {
            for (int j = n - 1; j > i; j--) {
                if (arr.get(i) > arr.get(j)) {
                    dec[i] = Math.max(dec[i], dec[j] + arr.get(i));
                }
            }
        }

        // Find the maximum sum of a bitonic subsequence
        long maxSum = 0;
        for (int i = 0; i < n; i++) {
            maxSum = Math.max(maxSum, inc[i] + dec[i] - arr.get(i));
        }

        return maxSum;
    }

}

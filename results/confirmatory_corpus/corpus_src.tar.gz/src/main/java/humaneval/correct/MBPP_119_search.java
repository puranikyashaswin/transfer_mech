package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_119_search {
    // Write a javathon function to find the element that appears only once in a sorted array array list.

    // Write a javathon function to find the element that appears only once in a sorted array array list.
    public static long search(ArrayList<Long> arr) {
        if (arr == null || arr.size() == 0) {
            throw new IllegalArgumentException("Array cannot be null or empty");
        }

        int left = 0;
        int right = arr.size() - 1;

        while (left < right) {
            int mid = left + (right - left) / 2;

            // If mid is even, check if the element at mid is the same as the element at mid + 1
            if (mid % 2 == 0) {
                if (arr.get(mid).equals(arr.get(mid + 1))) {
                    left = mid + 2; // The odd element is in the right half
                } else {
                    right = mid; // The odd element is in the left half
                }
            } 
            // If mid is odd, check if the element at mid is the same as the element at mid - 1
            else {
                if (arr.get(mid).equals(arr.get(mid - 1))) {
                    left = mid + 1; // The odd element is in the right half
                } else {
                    right = mid - 1; // The odd element is in the left half
                }
            }
        }

        return arr.get(left);
    }

}

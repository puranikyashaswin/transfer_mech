package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_420_cube_sum {
    // Write a javathon function to find the cube sum of first n even natural numbers.

    // Write a javathon function to find the cube sum of first n even natural numbers.
    public static long cubeSum(long n) {
        long sum = 0;
        for (long i = 1; i <= n; i++) {
            long evenNumber = 2 * i;
            sum += Math.pow(evenNumber, 3);
        }
        return sum;
    }

}

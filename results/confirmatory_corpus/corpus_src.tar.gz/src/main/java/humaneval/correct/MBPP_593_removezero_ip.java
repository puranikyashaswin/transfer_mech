package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_593_removezero_ip {
    // Write a function to remove leading zeroes from an ip address.

    // Write a function to remove leading zeroes from an ip address.
    public static String removezeroIp(String ip) {
        // Split the IP address into its components
        String[] parts = ip.split("\\.");
        
        // Remove leading zeroes from each component
        for (int i = 0; i < parts.length; i++) {
            parts[i] = parts[i].replaceFirst("^0+(?!$)", "");
        }
        
        // Join the components back into a single string
        return String.join(".", parts);
    }

}

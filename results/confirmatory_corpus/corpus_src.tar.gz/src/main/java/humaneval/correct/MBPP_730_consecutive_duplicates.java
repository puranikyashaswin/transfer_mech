package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_730_consecutive_duplicates {
    // Write a function to remove consecutive duplicates of a given array list.

    // Write a function to remove consecutive duplicates of a given array list.
    public static ArrayList<Object> consecutiveDuplicates(ArrayList<Object> nums) {
        if (nums == null || nums.size() <= 1) {
            return nums;
        }

        ArrayList<Object> result = new ArrayList<>();
        Object lastElement = null;

        for (Object num : nums) {
            if (!num.equals(lastElement)) {
                result.add(num);
                lastElement = num;
            }
        }

        return result;
    }

}

package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_100_make_a_pile {
    // Given a positive integer n, you have to make a pile of n levels of stones.
    // The first level has n stones.
    // The number of stones in the next level is:
    // - the next odd number if n is odd.
    // - the next even number if n is even.
    // Return the number of stones in each level in an array array list, where element at index
    // i represents the number of stones in the level (i+1).
    // Examples:
    // >>> makeAPile((3l))
    // (new ArrayList<Long>(Arrays.asList((long)3l, (long)5l, (long)7l)))

    // Given a positive integer n, you have to make a pile of n levels of stones.
    // The first level has n stones.
    // The number of stones in the next level is:
    // - the next odd number if n is odd.
    // - the next even number if n is even.
    // Return the number of stones in each level in an array list, where element at index
    // i represents the number of stones in the level (i+1).
    // Examples:
    // >>> makeAPile((3l))
    // (new ArrayList<Long>(Arrays.asList((long)3l, (long)5l, (long)7l)))
    public static ArrayList<Long> makeAPile(long n) {
        ArrayList<Long> result = new ArrayList<>();
        long currentStones = n;
        
        for (int i = 0; i < n; i++) {
            result.add(currentStones);
            // Determine the next number of stones based on the current number
            if (currentStones % 2 == 0) {
                currentStones += 2; // Next even number
            } else {
                currentStones += 2; // Next odd number
            }
        }
        
        return result;
    }

}

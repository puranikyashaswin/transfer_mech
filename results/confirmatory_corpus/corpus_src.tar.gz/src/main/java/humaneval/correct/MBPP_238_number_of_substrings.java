package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_238_number_of_substrings {
    // Write a javathon function to count the number of non-empty substrings of a given string.

    // Write a javathon function to count the number of non-empty substrings of a given string.
    public static long numberOfSubstrings(String str) {
        int n = str.length();
        return (long) n * (n + 1) / 2;
    }

}

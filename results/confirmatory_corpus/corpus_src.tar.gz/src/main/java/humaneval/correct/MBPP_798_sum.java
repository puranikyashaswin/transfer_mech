package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_798_sum {
    // Write a javathon function to find the sum of an array array list.

    // Write a javathon function to find the sum of an array array list.
    public static long Sum(ArrayList<Long> arr) {
        return arr.stream().mapToLong(Long::longValue).sum();
    }

}

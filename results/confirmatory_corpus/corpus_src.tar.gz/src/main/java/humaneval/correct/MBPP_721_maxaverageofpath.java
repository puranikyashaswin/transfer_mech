package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_721_maxaverageofpath {
    // Given a square matrix of size N*N given as an array array list of array lists, where each cell is associated with a specific cost. A path is defined as a specific sequence of cells that starts from the top-left cell move only right or down and ends on bottom right cell. We want to find a path with the maximum average over all existing paths. Average is computed as total cost divided by the number of cells visited in the path.

    // Given a square matrix of size N*N given as an array array list of array lists, where each cell is associated with a specific cost. A path is defined as a specific sequence of cells that starts from the top-left cell move only right or down and ends on bottom right cell. We want to find a path with the maximum average over all existing paths. Average is computed as total cost divided by the number of cells visited in the path.
    public static float maxAverageOfPath(ArrayList<ArrayList<Long>> cost) {
        int n = cost.size();
        long[][] dp = new long[n][n];
        
        // Initialize the first cell
        dp[0][0] = cost.get(0).get(0);
        
        // Fill the first row
        for (int j = 1; j < n; j++) {
            dp[0][j] = dp[0][j - 1] + cost.get(0).get(j);
        }
        
        // Fill the first column
        for (int i = 1; i < n; i++) {
            dp[i][0] = dp[i - 1][0] + cost.get(i).get(0);
        }
        
        // Fill the rest of the matrix
        for (int i = 1; i < n; i++) {
            for (int j = 1; j < n; j++) {
                dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]) + cost.get(i).get(j);
            }
        }
        
        // The maximum path sum is in the bottom-right cell
        long maxPathSum = dp[n - 1][n - 1];
        
        // Calculate the number of cells visited in the path
        int numCellsVisited = n * 2 - 1;
        
        // Return the maximum average
        return (float) maxPathSum / numCellsVisited;
    }

}

package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_71_comb_sort {
    // Write a function to sort an array array list of elements.

    // Write a function to sort an array array list of elements.
    public static ArrayList<Long> combSort(ArrayList<Long> nums) {
        if (nums == null || nums.size() <= 1) {
            return nums;
        }

        int gap = nums.size();
        boolean swapped = true;

        while (gap > 1 || swapped) {
            gap = Math.max(1, (int) (gap / 1.3));
            swapped = false;

            for (int i = 0; i < nums.size() - gap; i++) {
                if (nums.get(i) > nums.get(i + gap)) {
                    Collections.swap(nums, i, i + gap);
                    swapped = true;
                }
            }
        }

        return nums;
    }

}

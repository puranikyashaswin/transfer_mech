package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_11_string_xor {
    // Input are two strings a and b consisting only of 1s and 0s.
    // Perform binary XOR on these inputs and return result also as a string.
    // >>> stringXor(("010"), ("110"))
    // ("100")

    // Input are two strings a and b consisting only of 1s and 0s.
    // Perform binary XOR on these inputs and return result also as a string.
    // >>> stringXor(("010"), ("110"))
    // ("100")
    public static String stringXor(String a, String b) {
        StringBuilder result = new StringBuilder();
        
        // Ensure both strings are of the same length by padding the shorter one with leading zeros
        int maxLength = Math.max(a.length(), b.length());
        a = String.format("%" + maxLength + "s", a).replace(' ', '0');
        b = String.format("%" + maxLength + "s", b).replace(' ', '0');
        
        for (int i = 0; i < maxLength; i++) {
            char bitA = a.charAt(i);
            char bitB = b.charAt(i);
            
            // Perform XOR operation and append the result to the result string
            if (bitA == bitB) {
                result.append('0');
            } else {
                result.append('1');
            }
        }
        
        return result.toString();
    }

}

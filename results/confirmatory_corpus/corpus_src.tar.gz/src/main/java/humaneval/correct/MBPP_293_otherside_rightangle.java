package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_293_otherside_rightangle {
    // Write a function to find the third side of a right angled triangle.

    // Write a function to find the third side of a right angled triangle.
    public static float othersideRightangle(long w, long h) {
        // Calculate the square of the hypotenuse using the Pythagorean theorem
        long hypotenuseSquared = w * w + h * h;
        
        // Calculate the third side (hypotenuse)
        float hypotenuse = (float) Math.sqrt(hypotenuseSquared);
        
        return hypotenuse;
    }

}

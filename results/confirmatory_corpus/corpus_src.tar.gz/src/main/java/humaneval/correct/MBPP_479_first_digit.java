package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_479_first_digit {
    // Write a javathon function to find the first digit of a given number.

    // Write a javathon function to find the first digit of a given number.
    public static long firstDigit(long n) {
        if (n < 0) {
            n = -n; // Make the number positive for simplicity
        }
        while (n >= 10) {
            n /= 10; // Remove the last digit
        }
        return n;
    }

}

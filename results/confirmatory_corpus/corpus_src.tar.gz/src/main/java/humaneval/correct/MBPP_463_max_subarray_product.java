package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_463_max_subarray_product {
    // Write a function to find the maximum product subarray array list of the given array array list.

    // Write a function to find the maximum product subarray array list of the given array array list.
    public static long maxSubarrayProduct(ArrayList<Long> arr) {
        if (arr == null || arr.isEmpty()) {
            throw new IllegalArgumentException("Array cannot be null or empty");
        }

        long maxProduct = arr.get(0);
        long minProduct = arr.get(0);
        long result = arr.get(0);

        for (int i = 1; i < arr.size(); i++) {
            long current = arr.get(i);

            if (current < 0) {
                long temp = maxProduct;
                maxProduct = minProduct;
                minProduct = temp;
            }

            maxProduct = Math.max(current, maxProduct * current);
            minProduct = Math.min(current, minProduct * current);

            result = Math.max(result, maxProduct);
        }

        return result;
    }

}

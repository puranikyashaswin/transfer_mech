package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_49_modp {
    // Return 2^n modulo p (be aware of numerics).
    // >>> modp((3l), (5l))
    // (3l)
    // >>> modp((1101l), (101l))
    // (2l)
    // >>> modp((0l), (101l))
    // (1l)
    // >>> modp((3l), (11l))
    // (8l)
    // >>> modp((100l), (101l))
    // (1l)

    // Return 2^n modulo p (be aware of numerics).
    // >>> modp((3l), (5l))
    // (3l)
    // >>> modp((1101l), (101l))
    // (2l)
    // >>> modp((0l), (101l))
    // (1l)
    // >>> modp((3l), (11l))
    // (8l)
    // >>> modp((100l), (101l))
    // (1l)
    public static long modp(long n, long p) {
        if (p == 1) return 0;
        long result = 1;
        long base = 2 % p;
        while (n > 0) {
            if ((n & 1) == 1) {
                result = (result * base) % p;
            }
            base = (base * base) % p;
            n >>= 1;
        }
        return result;
    }

}

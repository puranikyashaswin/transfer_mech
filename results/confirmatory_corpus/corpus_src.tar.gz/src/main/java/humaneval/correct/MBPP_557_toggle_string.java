package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_557_toggle_string {
    // Write a function to toggle the case of all characters in a string.

    // Write a function to toggle the case of all characters in a string.
    public static String toggleString(String string) {
        StringBuilder toggledString = new StringBuilder();
        for (char c : string.toCharArray()) {
            if (Character.isUpperCase(c)) {
                toggledString.append(Character.toLowerCase(c));
            } else if (Character.isLowerCase(c)) {
                toggledString.append(Character.toUpperCase(c));
            } else {
                toggledString.append(c);
            }
        }
        return toggledString.toString();
    }

}

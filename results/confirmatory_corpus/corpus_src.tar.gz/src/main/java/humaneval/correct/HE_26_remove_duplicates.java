package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class HE_26_remove_duplicates {
    // From an array array list of integers, remove all elements that occur more than once.
    // Keep order of elements left the same as in the input.
    // >>> removeDuplicates((new ArrayList<Long>(Arrays.asList((long)1l, (long)2l, (long)3l, (long)2l, (long)4l))))
    // (new ArrayList<Long>(Arrays.asList((long)1l, (long)3l, (long)4l)))

    // From an array array list of integers, remove all elements that occur more than once.
    // Keep order of elements left the same as in the input.
    // >>> removeDuplicates((new ArrayList<Long>(Arrays.asList((long)1l, (long)2l, (long)3l, (long)2l, (long)4l))))
    // (new ArrayList<Long>(Arrays.asList((long)1l, (long)3l, (long)4l)))
    public static ArrayList<Long> removeDuplicates(ArrayList<Long> numbers) {
        Map<Long, Integer> countMap = new HashMap<>();
        
        // Count occurrences of each number
        for (Long number : numbers) {
            countMap.put(number, countMap.getOrDefault(number, 0) + 1);
        }
        
        // Create a new list to store unique numbers
        ArrayList<Long> uniqueNumbers = new ArrayList<>();
        
        // Add numbers to the new list only if they occur once
        for (Long number : numbers) {
            if (countMap.get(number) == 1) {
                uniqueNumbers.add(number);
            }
        }
        
        return uniqueNumbers;
    }

}

package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_619_move_num {
    // Write a function to move all the numbers to the end of the given string.

    // Write a function to move all the numbers to the end of the given string.
    public static String moveNum(String test_str) {
        StringBuilder letters = new StringBuilder();
        StringBuilder numbers = new StringBuilder();

        for (char c : test_str.toCharArray()) {
            if (Character.isDigit(c)) {
                numbers.append(c);
            } else {
                letters.append(c);
            }
        }

        return letters.toString() + numbers.toString();
    }

}

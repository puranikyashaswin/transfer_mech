package humaneval.correct;



public class MBPP_224_count_set_bits {
    // Write a javathon function to count the number of set bits (binary digits with value 1) in a given number.
public static long countSetBits(long n) {
    long count = 0;
    while (n > 0) {
        count += n & 1; // Increment count if the least significant bit is 1
        n >>= 1; // Right shift n by 1 to check the next bit
    }
    return count;
}

}

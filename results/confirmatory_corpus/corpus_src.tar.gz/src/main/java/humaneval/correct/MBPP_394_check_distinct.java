package humaneval.correct;

import java.util.*;


public class MBPP_394_check_distinct {
    // Write a function to check if given array list contains no duplicates.

    // Write a function to check if given array list contains no duplicates.
    public static boolean checkDistinct(ArrayList<Long> test_tup) {
        Set<Long> seen = new HashSet<>();
        for (Long num : test_tup) {
            if (!seen.add(num)) {
                return false;
            }
        }
        return true;
    }

}

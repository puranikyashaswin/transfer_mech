package humaneval.correct;

import java.util.*;


public class MBPP_168_frequency {
    // Write a function to count the number of occurrences of a number in a given array list.

    // Write a function to count the number of occurrences of a number in a given array list.
    public static long frequency(ArrayList<Long> a, long x) {
        return a.stream().filter(num -> num == x).count();
    }

}

package humaneval.correct;



public class MBPP_441_surfacearea_cube {
    // Write a function to find the surface area of a cube of a given size.
public static long surfaceareaCube(long l) {
    return 6 * l * l;
}

}

package humaneval.correct;

import java.util.*;


public class MBPP_741_all_characters_same {
    // Write a javathon function to check whether all the characters are same or not.

    // Write a javathon function to check whether all the characters are same or not.
    public static boolean allCharactersSame(String s) {
        if (s == null || s.length() <= 1) {
            return true;
        }
        
        char firstChar = s.charAt(0);
        for (int i = 1; i < s.length(); i++) {
            if (s.charAt(i) != firstChar) {
                return false;
            }
        }
        
        return true;
    }

}

package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_635_heap_sort {
    // Write a function to sort the given array list.

    // Write a function to sort the given array list.
    public static ArrayList<Long> heapSort(ArrayList<Long> iterable) {
        if (iterable == null || iterable.isEmpty()) {
            return iterable;
        }

        int n = iterable.size();
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(iterable, n, i);
        }

        for (int i = n - 1; i > 0; i--) {
            Collections.swap(iterable, 0, i);
            heapify(iterable, i, 0);
        }

        return iterable;
    }

    private static void heapify(ArrayList<Long> iterable, int n, int i) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < n && iterable.get(left) > iterable.get(largest)) {
            largest = left;
        }

        if (right < n && iterable.get(right) > iterable.get(largest)) {
            largest = right;
        }

        if (largest != i) {
            Collections.swap(iterable, i, largest);
            heapify(iterable, n, largest);
        }
    }

}

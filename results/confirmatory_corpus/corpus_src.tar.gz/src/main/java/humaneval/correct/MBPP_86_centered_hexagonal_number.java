package humaneval.correct;



public class MBPP_86_centered_hexagonal_number {
    // Write a function to find nth centered hexagonal number.
public static long centeredHexagonalNumber(long n) {
    return 3 * n * (n - 1) + 1;
}

}

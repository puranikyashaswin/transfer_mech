package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_731_lateralsurface_cone {
    // Write a function to find the lateral surface area of a cone given radius r and the height h.

    // Write a function to find the lateral surface area of a cone given radius r and the height h.
    public static float lateralsurfaceCone(long r, long h) {
        // Calculate the slant height using the Pythagorean theorem
        double slantHeight = Math.sqrt(r * r + h * h);
        
        // Calculate the lateral surface area using the formula: π * r * l
        float lateralSurfaceArea = (float) (Math.PI * r * slantHeight);
        
        return lateralSurfaceArea;
    }

}

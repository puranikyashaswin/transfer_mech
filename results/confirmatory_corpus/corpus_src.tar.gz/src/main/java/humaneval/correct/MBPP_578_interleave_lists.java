package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_578_interleave_lists {
    // Write a function to interleave 3 array lists of the same length into a single flat array list.

    // Write a function to interleave 3 array lists of the same length into a single flat array list.
    public static ArrayList<Long> interleaveLists(ArrayList<Long> list1, ArrayList<Long> list2, ArrayList<Long> list3) {
        ArrayList<Long> result = new ArrayList<>();
        for (int i = 0; i < list1.size(); i++) {
            result.add(list1.get(i));
            result.add(list2.get(i));
            result.add(list3.get(i));
        }
        return result;
    }

}

package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_629_split {
    // Write a javathon function to find even numbers from an array array list of numbers.

    // Write a javathon function to find even numbers from an array array list of numbers.
    public static ArrayList<Long> Split(ArrayList<Long> list) {
        ArrayList<Long> evenNumbers = new ArrayList<>();
        for (Long number : list) {
            if (number % 2 == 0) {
                evenNumbers.add(number);
            }
        }
        return evenNumbers;
    }

}

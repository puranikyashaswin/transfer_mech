package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_784_mul_even_odd {
    // Write a function to find the product of first even and odd number of a given array list.

    // Write a function to find the product of first even and odd number of a given array list.
    public static long mulEvenOdd(ArrayList<Long> list1) {
        long evenProduct = 1;
        long oddProduct = 1;
        boolean evenFound = false;
        boolean oddFound = false;

        for (Long num : list1) {
            if (num % 2 == 0) {
                if (!evenFound) {
                    evenProduct *= num;
                    evenFound = true;
                }
            } else {
                if (!oddFound) {
                    oddProduct *= num;
                    oddFound = true;
                }
            }

            // If both even and odd numbers are found, break early
            if (evenFound && oddFound) {
                break;
            }
        }

        // If either even or odd number was not found, return 0
        if (!evenFound || !oddFound) {
            return 0;
        }

        return evenProduct * oddProduct;
    }

}

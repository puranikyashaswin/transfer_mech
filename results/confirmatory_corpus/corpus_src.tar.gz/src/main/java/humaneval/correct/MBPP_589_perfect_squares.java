package humaneval.correct;

import java.util.*;


public class MBPP_589_perfect_squares {
    // Write a function to find perfect squares between two given numbers.

    // Write a function to find perfect squares between two given numbers.
    public static ArrayList<Long> perfectSquares(long a, long b) {
        ArrayList<Long> result = new ArrayList<>();
        
        // Ensure a is less than or equal to b
        if (a > b) {
            long temp = a;
            a = b;
            b = temp;
        }
        
        // Find the smallest integer whose square is greater than or equal to a
        long start = (long) Math.ceil(Math.sqrt(a));
        
        // Find the largest integer whose square is less than or equal to b
        long end = (long) Math.floor(Math.sqrt(b));
        
        // Add all perfect squares between start and end to the result list
        for (long i = start; i <= end; i++) {
            result.add(i * i);
        }
        
        return result;
    }

}

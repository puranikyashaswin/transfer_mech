package humaneval.correct;

import java.util.*;


public class MBPP_760_unique_element {
    // Write a javathon function to check whether an array array list of numbers contains only one distinct element or not.

    // Write a javathon function to check whether an array array list of numbers contains only one distinct element or not.
    public static boolean uniqueElement(ArrayList<Long> arr) {
        if (arr == null || arr.size() == 0) {
            return false;
        }
        
        Set<Long> uniqueElements = new HashSet<>(arr);
        return uniqueElements.size() == 1;
    }

}

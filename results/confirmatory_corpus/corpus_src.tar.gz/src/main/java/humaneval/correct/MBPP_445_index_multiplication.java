package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_445_index_multiplication {
    // Write a function to perform index wise multiplication of array list elements in the given two array lists.

    // Write a function to perform index wise multiplication of array list elements in the given two array lists.
    public static ArrayList<ArrayList<Long>> indexMultiplication(ArrayList<ArrayList<Long>> test_tup1, ArrayList<ArrayList<Long>> test_tup2) {
        ArrayList<ArrayList<Long>> result = new ArrayList<>();
        
        for (int i = 0; i < test_tup1.size(); i++) {
            ArrayList<Long> rowResult = new ArrayList<>();
            for (int j = 0; j < test_tup1.get(i).size(); j++) {
                long product = test_tup1.get(i).get(j) * test_tup2.get(i).get(j);
                rowResult.add(product);
            }
            result.add(rowResult);
        }
        
        return result;
    }

}

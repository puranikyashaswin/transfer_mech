package humaneval.correct;

import java.util.*;


public class HE_16_count_distinct_characters {
    // Given a string, find out how many distinct characters (regardless of case) does it consist of
    // >>> countDistinctCharacters(("xyzXYZ"))
    // (3l)
    // >>> countDistinctCharacters(("Jerry"))
    // (4l)

    public static long countDistinctCharacters(String string) {
        // Convert the string to lowercase to ensure case insensitivity
        string = string.toLowerCase();
        
        // Use a Set to store unique characters
        Set<Character> uniqueChars = new HashSet<>();
        
        // Iterate over each character in the string
        for (char c : string.toCharArray()) {
            // Add the character to the set
            uniqueChars.add(c);
        }
        
        // Return the size of the set, which represents the number of distinct characters
        return uniqueChars.size();
    }

}

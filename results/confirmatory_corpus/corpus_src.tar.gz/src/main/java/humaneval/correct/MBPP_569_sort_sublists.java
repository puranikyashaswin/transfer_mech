package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_569_sort_sublists {
    // Write a function to sort each subarray list of strings in a given array list of array lists.

    // Write a function to sort each subarray list of strings in a given array list of array lists.
    public static ArrayList<ArrayList<String>> sortSublists(ArrayList<ArrayList<String>> list1) {
        for (ArrayList<String> sublist : list1) {
            sublist.sort(Comparator.naturalOrder());
        }
        return list1;
    }

}

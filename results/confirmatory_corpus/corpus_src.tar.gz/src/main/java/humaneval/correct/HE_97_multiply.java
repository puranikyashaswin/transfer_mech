package humaneval.correct;



public class HE_97_multiply {
    // Complete the function that takes two integers and returns 
    // the product of their unit digits.
    // Assume the input is always valid.
    // Examples:
    // >>> multiply((148l), (412l))
    // (16l)
    // >>> multiply((19l), (28l))
    // (72l)
    // >>> multiply((2020l), (1851l))
    // (0l)
    // >>> multiply((14l), (-15l))
    // (20l)
public static long multiply(long a, long b) {
    // Get the absolute values of the unit digits
    int unitDigitA = Math.abs((int) (a % 10));
    int unitDigitB = Math.abs((int) (b % 10));
    
    // Return the product of the unit digits
    return (long) unitDigitA * unitDigitB;
}

}

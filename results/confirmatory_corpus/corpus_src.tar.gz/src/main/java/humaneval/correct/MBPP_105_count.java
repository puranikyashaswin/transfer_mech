package humaneval.correct;

import java.util.*;


public class MBPP_105_count {
    // Write a javathon function to count true booleans in the given array list.

    // Write a javathon function to count true booleans in the given array list.
    public static long count(ArrayList<Boolean> lst) {
        return lst.stream().filter(Boolean::booleanValue).count();
    }

}

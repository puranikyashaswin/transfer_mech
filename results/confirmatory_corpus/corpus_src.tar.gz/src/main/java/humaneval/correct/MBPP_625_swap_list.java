package humaneval.correct;

import java.util.*;


public class MBPP_625_swap_list {
    // Write a javathon function to interchange the first and last element in a given array list.

    // Write a javathon function to interchange the first and last element in a given array list.
    public static ArrayList<Long> swapList(ArrayList<Long> newList) {
        if (newList == null || newList.size() < 2) {
            return newList; // Return the list as is if it's null or has less than 2 elements
        }
        
        long firstElement = newList.get(0);
        long lastElement = newList.get(newList.size() - 1);
        
        newList.set(0, lastElement);
        newList.set(newList.size() - 1, firstElement);
        
        return newList;
    }

}

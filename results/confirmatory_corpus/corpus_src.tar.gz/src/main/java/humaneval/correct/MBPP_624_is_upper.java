package humaneval.correct;

import java.util.*;
import java.lang.reflect.*;
import org.javatuples.*;
import java.security.*;
import java.math.*;
import java.io.*;
import java.util.stream.*;


public class MBPP_624_is_upper {
    // Write a javathon function to convert a given string to uppercase.

    // Write a javathon function to convert a given string to uppercase.
    public static String isUpper(String string) {
        return string.toUpperCase();
    }

}
